# Dear ImGui 1.93 integration

Upstream: `ocornut/imgui`, stable tag `v1.93.0-docking`, commit
`4e02e84cbb85d48881388e7090c2dfa1708c02a1` (14 October 2026).
ReaImGui master was checked at `b3466c103d9ccd64b1192a2615f2188d1e739ab8`;
it has no mainline changes beyond this fork's baseline.

The complete vendored release tree was updated. New upstream backends are
reference code; nvk_GUI continues to build its own Metal, OpenGL, and D3D10
backends. Updating Dear ImGui does not switch the renderer implementation.

## Retained patches

- REAPER viewport transparency/rounding, window-position reconciliation,
  per-frame viewport flags, first-frame framebuffer scale, and size bounds.
- EM-sized fonts with independent line height, explicit font merge targets,
  font-source user data, and lazy system-font fallback. Fallback uses the new
  glyph-index loader interface, initializes every added source for every live
  bake, and retains upstream codepoint-to-glyph remapping.
- `StyleVar_ButtonBorderSize` and `Col_ButtonBorder`: a border around buttons
  only, so plain buttons can match nvk's bordered field buttons without
  `FrameBorderSize` outlining every frame. It is skipped while a frame border
  is pushed and for buttons with a transparent resting fill (text and icon
  buttons). Both are appended after the upstream enums, so no existing index
  moves.
- `InputTextFlags_EscapeKeepsEdits`. Existing word-wrap/text-edit backports are
  superseded by upstream implementations; their independent-line-height
  adaptations remain.
- Subpixel text positioning now uses upstream `ImDrawFlags_TextNoPixelSnap`;
  the script-facing `DrawList_SetTextPixelSnap` function is unchanged.
- FreeType size activation (fixed 2026-11-01). Upstream skips `FT_Activate_Size`
  when the glyph's bake is the one it last activated, compared by address. Bake
  collection moves bakes within the pool, and discarding the active size makes
  FreeType activate another one. So a moved bake could match the cached address
  while its face was sized for a different bake. Glyphs loaded then were
  rasterized at that other size: the Terminal's `nvk_MONO` text showed letters
  at mixed sizes inside one word. The loader now activates whenever the face's
  active `FT_Size` is not the bake's own. Regression test:
  `ImGuiUpgradeFreeTypeTest.BakeMovedByCollectionRasterizesAtItsOwnSize`.

## Binding compatibility

Lua drawing argument order is unchanged. The wrapper translates `Closed = 1`
to the new internal bit, preserves the `RoundCorners*` names, and calls the new
C++ argument order. New style fields are included in the indexed style table.
Old tab fitting names remain supported; an unspecified fitting policy retains
shrink-to-fit behavior. Scalar keyboard edits remain live as in the old binding.
Color-edit options retain default-mask filling, and TextFilter_Draw retains its
width argument through SetNextItemWidth.

Contexts enable upstream's legacy stroke mode to retain existing custom-drawing
coordinates while using the new implementation. This is a compatibility choice,
not a claim of pixel-for-pixel equivalence for every shape: upstream documents
some differences in thick acute joins. Native-region scratch lists now inherit
pixel density from their source list, as required by 1.93.

## Performance changes

- Native composition retains vertex/index capacity across replays.
- Native painter point conversion and script polygon conversion use storage
  owned by the compositor/context rather than allocating for each call.
- Identical-frame detection compares current draw data directly with the last
  retained snapshot. Changed frames still take an exact snapshot before render;
  callbacks, pending texture changes, and pending destruction prevent skipping.
- macOS monitor geometry is shared across contexts. Display/Space notifications
  invalidate it immediately; a 500 ms fallback poll covers other work-area
  changes. Windows and Linux retain their existing monitor enumeration.

A larger retained-static-geometry compositor redesign is deferred pending a
real workload showing that the remaining copy cost warrants it. See
[measurements](MEASUREMENTS.md) for the CPU microbenchmark and its limitations.

## Verification

Run `python3 tools/check.py gui` from the root. The opt-in CPU benchmark is:

```
out/gui/tests/tests --gtest_also_run_disabled_tests --gtest_filter='DrawProfileTest.*'
```

`tools/upgrade_smoke.lua` is a disposable-host-only live harness. Copy it into
the session's source tree and dispatch it with the disposable-reaper runner.
It reports to `host/gui-upgrade-result.txt`; create `host/gui-upgrade-stop` to
end its deferred loop. It neither quits the host nor edits a project.

Validated on macOS/Apple M3 Max with Metal: three concurrent shared-atlas
contexts, Unicode fallback, wrapped input, drawing APIs, stock ReaImGui
coexistence, and SIGNAL's main/pop-out editing views. The SIGNAL harness needed
a longer startup timeout (30 seconds instead of 10); both the installed baseline
and upgraded build completed 12 frames in each view. Live visual inspection
confirmed repainting and text/shapes after bringing the window out of occlusion.
Windows/Linux and mixed-DPI display hot-plug were not exercised live.
