# Building this release's nvk_GUI

This archive accompanies the nvk_API package. SOURCE.json identifies the exact monorepo commit and hashes every
source file. The modified Dear ImGui source, WDL and REAPER SDK sources, md4c and the pinned Meson dependency
archives/patches are included. COPYING and COPYING.LESSER contain the license texts. This is source, not an
installed extension; modifying or rebuilding it does not modify your scripts or their settings.

Install a C++20 compiler, Python 3, Meson >= 1.1, Ninja, and Boost >= 1.81 headers. Windows requires MSVC or clang-cl
and NASM. Linux also requires the Fontconfig, GTK 3 and libepoxy development packages. The compiler, SDK, operating
system libraries and Boost are system build prerequisites; see README.md for details. Windows release builds use
Boost 1.87.0. Meson can download the public Boost 1.84.0 fallback declared in subprojects/boost.wrap if needed.

From the extracted nvk_GUI directory, build and test without installing:

    meson setup build --buildtype=release --wrap-mode=nodownload --force-fallback-for=freetype2,libjpeg,libpng,zlib,fmt -Dbindings=[]
    meson compile -C build
    meson compile -C build tests/tests
    meson test -C build --print-errorlogs nvkgui

On macOS set MACOSX_DEPLOYMENT_TARGET=14.0 first. For Intel cross compilation, add --cross-file cross/nvk-release-intel.ini;
tests require Rosetta on Apple Silicon. On Linux the distributed build targets Ubuntu 22.04/glibc 2.35 with GCC 13
and adds -Dcpp_link_args=['-static-libstdc++','-static-libgcc']. On Windows run from an MSVC developer shell; the
default release configuration uses the static Microsoft runtime. A build from this archive has unknown Git
provenance by design; it can be used locally, but is not an official signed binary.

To install your build, close REAPER, point Meson at its resource directory, then install only runtime files:

    meson configure build -Dresource_path=/absolute/path/to/REAPER-resource
    meson install -C build --tags runtime

Restart REAPER after replacing an extension. Stock ReaImGui and nvk_GUI can coexist. No private repository,
nvk_API source, account credentials or monorepo bootstrap is required to build this source.
