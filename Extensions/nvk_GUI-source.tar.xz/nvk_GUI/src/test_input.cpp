/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "test_input.hpp"

#include <algorithm>
#include <imgui/imgui_internal.h>

void TestInput::take(ImGuiContext *ctx, const double now)
{
  m_lastInjection = now;
  if(m_owned)
    return;

  // Whatever the person was holding (and anything still queued from them)
  // would otherwise be released by events this class now drops.
  ImGuiIO &io {ctx->IO};
  ctx->InputEventsQueue.resize(0);
  const ImVec2 mousePos {io.MousePos};
  io.ClearInputKeys();
  io.ClearInputMouse();
  io.MousePos = mousePos;
  io.MouseCtrlLeftAsRightClick = false;

  m_owned = true;
  m_haveCursor = false;
}

void TestInput::move(ImGuiContext *ctx, const ImGuiID viewport,
  const ImVec2 position, const double now)
{
  take(ctx, now);
  ctx->IO.AddMouseViewportEvent(viewport);
  ctx->IO.AddMousePosEvent(position.x, position.y);
}

void TestInput::button(ImGuiContext *ctx, const int button, const bool down,
  const double now)
{
  IM_ASSERT(button >= 0 && button < ImGuiMouseButton_COUNT);
  take(ctx, now);

  // A button is the button asked for: no Ctrl+click right-click emulation.
  ImGuiIO &io {ctx->IO};
  const bool macBehaviors {io.ConfigMacOSXBehaviors};
  io.ConfigMacOSXBehaviors = false;
  io.AddMouseButtonEvent(button, down);
  io.ConfigMacOSXBehaviors = macBehaviors;

  if(down)
    m_buttons |= 1u << button;
  else
    m_buttons &= ~(1u << button);
}

void TestInput::wheel(ImGuiContext *ctx, const float horizontal,
  const float vertical, const double now)
{
  take(ctx, now);
  ctx->IO.AddMouseWheelEvent(horizontal, vertical);
}

bool TestInput::validKey(const ImGuiKey key)
{
  if(key == ImGuiMod_Ctrl || key == ImGuiMod_Shift ||
      key == ImGuiMod_Alt || key == ImGuiMod_Super)
    return true;
  return ImGui::IsNamedKey(key) && !ImGui::IsAliasKey(key) &&
    (key < ImGuiKey_ReservedForModCtrl || key > ImGuiKey_ReservedForModSuper);
}

void TestInput::focus(ImGuiContext *ctx, const char *window)
{
  const bool frontmost {!window || !*window};
  ImGuiWindow *const nav {ctx->NavWindow};
  if(frontmost && nav)
    return;

  ImGuiWindow *target {};
  if(!frontmost)
    target = ImGui::FindWindowByName(window);
  else {
    // The frontmost root window the script still shows.
    const auto &order {ctx->WindowsFocusOrder};
    for(int i {order.Size - 1}; i >= 0 && !target; --i) {
      ImGuiWindow *candidate {order[i]};
      if(candidate->WasActive && !(candidate->Flags &
          (ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_Popup |
           ImGuiWindowFlags_Tooltip)))
        target = candidate;
    }
  }
  if(!target || (nav && ImGui::IsWindowChildOf(nav, target, true, true)))
    return;
  ImGui::FocusWindow(target, ImGuiFocusRequestFlags_UnlessBelowModal);
}

void TestInput::key(ImGuiContext *ctx, const ImGuiKey key, const bool down,
  const double now)
{
  IM_ASSERT(validKey(key));
  take(ctx, now);
  // The key as a backend sends it: physical Command is Mod_Super, and ImGui
  // swaps it with Ctrl under ConfigMacOSXBehaviors like any real key.
  ctx->IO.AddKeyEvent(key, down);

  const auto it {std::find(m_keys.begin(), m_keys.end(), key)};
  if(down && it == m_keys.end())
    m_keys.push_back(key);
  else if(!down && it != m_keys.end())
    m_keys.erase(it);
}

void TestInput::text(ImGuiContext *ctx, const char *utf8, const double now)
{
  take(ctx, now);
  ctx->IO.AddInputCharactersUTF8(utf8);
}

void TestInput::hold(ImGuiContext *ctx, const double now)
{
  take(ctx, now);
}

void TestInput::release(ImGuiContext *ctx)
{
  if(!m_owned)
    return;

  ImGuiIO &io {ctx->IO};
  for(auto it {m_keys.rbegin()}; it != m_keys.rend(); ++it)
    io.AddKeyEvent(*it, false);
  m_keys.clear();
  const bool macBehaviors {io.ConfigMacOSXBehaviors};
  io.ConfigMacOSXBehaviors = false;
  for(int button {}; button < ImGuiMouseButton_COUNT; ++button) {
    if(m_buttons & (1u << button))
      io.AddMouseButtonEvent(button, false);
  }
  io.ConfigMacOSXBehaviors = macBehaviors;
  m_buttons = 0;

  m_owned = false;
  m_haveCursor = false;
}

bool TestInput::acceptRealEvent(ImGuiContext *ctx, const bool press,
  const double now)
{
  if(!m_owned)
    return true;
  if(busy(now) || !press)
    return false;
  release(ctx);
  return true;
}

bool TestInput::acceptRealCursor(ImGuiContext *ctx, const ImVec2 cursor,
  const bool overContext, const double now)
{
  if(!m_owned)
    return true;

  const bool moved {m_haveCursor &&
    (cursor.x != m_realCursor.x || cursor.y != m_realCursor.y)};
  m_realCursor = cursor;
  m_haveCursor = true;
  if(busy(now) || !moved || !overContext)
    return false;

  release(ctx);
  return true;
}
