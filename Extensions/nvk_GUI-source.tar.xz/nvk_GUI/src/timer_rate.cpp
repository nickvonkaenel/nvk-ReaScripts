/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "timer_rate.hpp"

#include "settings.hpp"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <reaper_plugin_functions.h>

#if defined(_WIN32)
#  include <windows.h>
#  include <psapi.h> // K32EnumProcessModules (kernel32 on Windows 7+)
#elif defined(__APPLE__)
#  include <mach-o/dyld.h>
#else
#  include <link.h>
#endif

// REAPER's misc timer on the main window (runs deferred scripts and
// extension timers)
constexpr UINT_PTR MISC_TIMER {0x29a};

// ticks to ignore after load (startup work stretches them), then ticks to
// measure the baseline interval over
constexpr size_t SKIP_TICKS {2}, MEASURE_TICKS {40};

// consecutive ticks slower than twice the chosen interval before re-arming
constexpr int SLOW_TICKS_REARM {30};

using Clock = std::chrono::steady_clock;

static std::vector<Clock::time_point> g_ticks;
static Clock::time_point g_lastTick;
static bool g_measuring, g_registered;
static int g_baselineMs, g_appliedMs; // g_appliedMs: 0 = never changed
static int g_slowTicks;

const std::vector<int> &TimerRate::choices()
{
  // Only rates measured to hold on the platform. SWELL's SetTimer takes any
  // interval. On Windows SetTimer has a 10 ms floor and coarse resolution, so
  // faster rates wait until they are measured there; Linux is unmeasured.
#ifdef __APPLE__
  static const std::vector<int> rates {60, 90, 120};
#else
  static const std::vector<int> rates {60};
#endif
  return rates;
}

bool TimerRate::isChoice(const int hz)
{
  const auto &rates {choices()};
  return std::find(rates.begin(), rates.end(), hz) != rates.end();
}

int TimerRate::intervalMs(const int hz)
{
  // integer division like reaper_60fps: 60 Hz => 16 ms (62.5 Hz)
  return hz > 0 ? 1000 / hz : 0;
}

int TimerRate::medianIntervalMs(std::vector<double> intervals)
{
  if(intervals.empty())
    return 0;

  const auto mid {intervals.begin() + intervals.size() / 2};
  std::nth_element(intervals.begin(), mid, intervals.end());
  return static_cast<int>(std::lround(*mid));
}

bool TimerRate::isForeignOverrideModule(std::string_view path)
{
  const auto slash {path.find_last_of("/\\")};
  if(slash != std::string_view::npos)
    path.remove_prefix(slash + 1);

  constexpr std::string_view prefix {"reaper_60fps"};
  if(path.size() < prefix.size())
    return false;
  return std::equal(prefix.begin(), prefix.end(), path.begin(),
    [](const char a, const char b) {
      return a == std::tolower(static_cast<unsigned char>(b));
    });
}

bool TimerRate::foreignOverrideLoaded()
{
  static const bool loaded {[] {
#if defined(_WIN32)
    HMODULE modules[1024];
    DWORD needed;
    if(!K32EnumProcessModules(GetCurrentProcess(), modules, sizeof(modules), &needed))
      return false;
    const size_t count {std::min<size_t>(needed / sizeof(HMODULE), std::size(modules))};
    for(size_t i {}; i < count; ++i) {
      char path[MAX_PATH];
      if(GetModuleFileNameA(modules[i], path, sizeof(path)) &&
          isForeignOverrideModule(path))
        return true;
    }
    return false;
#elif defined(__APPLE__)
    for(uint32_t i {}, count {_dyld_image_count()}; i < count; ++i) {
      if(const char *path {_dyld_get_image_name(i)}; path && isForeignOverrideModule(path))
        return true;
    }
    return false;
#else
    return dl_iterate_phdr([](dl_phdr_info *info, size_t, void *) {
      return info->dlpi_name && isForeignOverrideModule(info->dlpi_name) ? 1 : 0;
    }, nullptr) != 0;
#endif
  }()};

  return loaded;
}

int TimerRate::baselineIntervalMs()
{
  return g_baselineMs;
}

static void measure(const Clock::time_point now)
{
  g_ticks.push_back(now);
  if(g_ticks.size() < SKIP_TICKS + MEASURE_TICKS + 1)
    return;

  std::vector<double> intervals;
  for(size_t i {SKIP_TICKS + 1}; i < g_ticks.size(); ++i) {
    const std::chrono::duration<double, std::milli> delta {g_ticks[i] - g_ticks[i - 1]};
    intervals.push_back(delta.count());
  }
  g_ticks.clear();
  g_ticks.shrink_to_fit();

  g_baselineMs = TimerRate::medianIntervalMs(std::move(intervals));
  g_measuring = false;

  // Applied only now, after a third-party override's first-tick SetTimer (so
  // a chosen rate wins over it) and with a baseline to restore.
  TimerRate::apply();
}

// Re-arms a chosen rate if something reset REAPER's timer (REAPER re-arms it
// itself in some cases, see tick()).
static void watch(const Clock::time_point now)
{
  if(!g_appliedMs)
    return;

  const std::chrono::duration<double, std::milli> delta {now - g_lastTick};
  if(delta.count() <= g_appliedMs * 2) {
    g_slowTicks = 0;
    return;
  }

  if(++g_slowTicks >= SLOW_TICKS_REARM) {
    SetTimer(GetMainHwnd(), MISC_TIMER, g_appliedMs, nullptr);
    g_slowTicks = 0;
  }
}

// Stays registered for the extension's lifetime, as a no-op at the default
// rate. Unregistering REAPER's last extension timer makes REAPER re-arm its
// misc timer: measured on macOS, a background REAPER dropped from 30 ms to
// 100 ms ticks after this callback unregistered itself.
static void tick()
{
  const auto now {Clock::now()};
  if(g_measuring)
    measure(now);
  else
    watch(now);
  g_lastTick = now;
}

void TimerRate::setup()
{
  g_measuring = true;
  g_registered = plugin_register("timer", reinterpret_cast<void *>(&tick));
}

void TimerRate::teardown()
{
  if(g_registered)
    plugin_register("-timer", reinterpret_cast<void *>(&tick));
  g_registered = g_measuring = false;
}

void TimerRate::apply()
{
  if(g_measuring || !g_baselineMs)
    return; // measure() applies once the baseline is known

  const int target {isChoice(Settings::TimerRate) ? intervalMs(Settings::TimerRate) : 0};
  if(target == g_appliedMs)
    return;

  if(target)
    SetTimer(GetMainHwnd(), MISC_TIMER, target, nullptr);
  else // back to what REAPER (or another extension) had set
    SetTimer(GetMainHwnd(), MISC_TIMER, g_baselineMs, nullptr);

  g_appliedMs = target;
  g_slowTicks = 0;
}
