/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "native_region.hpp"

#include "color.hpp"

#include <chrono>
#include <cstring>
#include <imgui/imgui_internal.h>
#include <string>

struct Drawer {
  std::string name;
  NvkGui_RegionDrawer func;
  void *user;
};

static std::vector<Drawer> g_drawers; // indices stay valid: never shrinks

// Identifies our AddCallback commands. Renderers skip every callback, so it
// is never called; expand() replaces the commands before they render.
static void marker(const ImDrawList *, const ImDrawCmd *) {}

int NativeRegion::registerDrawer(const char *name,
  const NvkGui_RegionDrawer func, void *user)
{
  if(const int index {findDrawer(name)}; index >= 0) {
    g_drawers[index].func = func; // re-registration replaces (null disables)
    g_drawers[index].user = user;
    return index;
  }

  g_drawers.push_back({name, func, user});
  return static_cast<int>(g_drawers.size()) - 1;
}

int NativeRegion::findDrawer(const char *name)
{
  for(size_t i {}; i < g_drawers.size(); ++i) {
    if(g_drawers[i].name == name)
      return static_cast<int>(i);
  }
  return -1;
}

bool NativeRegion::add(ImDrawList *drawList, const int drawer,
  const double key, const ImVec2 min, const ImVec2 max)
{
  if(drawer < 0 || static_cast<size_t>(drawer) >= g_drawers.size() ||
      !g_drawers[drawer].func)
    return false;

  ImFont *font {drawList->_Data ? drawList->_Data->Font : nullptr};
  Payload payload {drawer, key, min, max, font,
    drawList->_Data ? drawList->_Data->FontSize : 0.f,
    font ? font->CurrentRasterizerDensity : 1.f,
    (drawList->Flags & ImDrawFlags_TextNoPixelSnap) != 0};
  drawList->AddCallback(&marker, &payload, sizeof(payload));
  return true;
}

static const NativeRegion::Payload *payloadOf(const ImDrawList &list,
  const ImDrawCmd &cmd)
{
  if(cmd.UserCallback != &marker ||
      cmd.UserCallbackDataSize != sizeof(NativeRegion::Payload))
    return nullptr;
  if(cmd.UserCallbackData) // resolved by Render()
    return static_cast<const NativeRegion::Payload *>(cmd.UserCallbackData);
  return reinterpret_cast<const NativeRegion::Payload *>(
    list._CallbacksDataBuf.Data + cmd.UserCallbackDataOffset);
}

bool NativeRegion::expand(const ImDrawList &src, ImDrawList &out,
  ImDrawList &scratch, const ImTextureRef atlas, const Paint &paint, bool *live)
{
  bool hasMarker {};
  for(const ImDrawCmd &cmd : src.CmdBuffer) {
    if(payloadOf(src, cmd)) {
      hasMarker = true;
      break;
    }
  }
  if(!hasMarker)
    return false;

  out.Flags = src.Flags;
  // ImVector assignment frees its allocation. Keep capacity across replays.
  out.VtxBuffer.resize(src.VtxBuffer.Size);
  if(src.VtxBuffer.Size)
    std::memcpy(out.VtxBuffer.Data, src.VtxBuffer.Data, src.VtxBuffer.size_in_bytes());
  out.IdxBuffer.resize(src.IdxBuffer.Size);
  if(src.IdxBuffer.Size)
    std::memcpy(out.IdxBuffer.Data, src.IdxBuffer.Data, src.IdxBuffer.size_in_bytes());
  out.CmdBuffer.resize(0);

  for(const ImDrawCmd &cmd : src.CmdBuffer) {
    const Payload *payload {payloadOf(src, cmd)};
    if(!payload) {
      out.CmdBuffer.push_back(cmd);
      continue;
    }

    // the region is clipped by both its rectangle and the window's clipping
    const ImVec4 &clip {cmd.ClipRect};
    const ImVec2 clipMin {ImMax(clip.x, payload->min.x), ImMax(clip.y, payload->min.y)},
                 clipMax {ImMin(clip.z, payload->max.x), ImMin(clip.w, payload->max.y)};
    if(clipMin.x >= clipMax.x || clipMin.y >= clipMax.y)
      continue;

    scratch._ResetForNewFrame();
    scratch._SetPixelDensity(src._InvFringeScale);
    scratch.PushTexture(atlas);
    scratch.PushClipRect(clipMin, clipMax);
    if(paint(*payload, &scratch) && live)
      *live = true;

    const unsigned int vtxBase {static_cast<unsigned int>(out.VtxBuffer.Size)},
                       idxBase {static_cast<unsigned int>(out.IdxBuffer.Size)};
    out.VtxBuffer.resize(vtxBase + scratch.VtxBuffer.Size);
    std::memcpy(out.VtxBuffer.Data + vtxBase, scratch.VtxBuffer.Data,
      scratch.VtxBuffer.Size * sizeof(ImDrawVert));
    out.IdxBuffer.resize(idxBase + scratch.IdxBuffer.Size);
    std::memcpy(out.IdxBuffer.Data + idxBase, scratch.IdxBuffer.Data,
      scratch.IdxBuffer.Size * sizeof(ImDrawIdx));

    for(ImDrawCmd painted : scratch.CmdBuffer) {
      if(!painted.ElemCount || painted.UserCallback)
        continue;
      painted.VtxOffset += vtxBase;
      painted.IdxOffset += idxBase;
      out.CmdBuffer.push_back(painted);
    }
  }

  return true;
}

// C painter table

struct NvkGui_RegionPainter {
  ImDrawList *drawList;
  std::vector<ImVec2> &points;
  const NativeRegion::Payload *payload;
};

// Mirrors IM_FONTGLYPH_INDEX_UNUSED and _NOT_FOUND (private to imgui_draw.cpp).
constexpr ImU16 GLYPH_UNUSED {0xFFFF}, GLYPH_NOT_FOUND {0xFFFE};

// The payload's font at its size as baked, or null. Read only: unlike
// ImFont::GetFontBaked this never creates a size, and unlike
// ImFontBaked::FindGlyph the caller never loads a glyph, so painting between
// frames leaves the atlas exactly as FontRegistry::newFrame left it.
static const ImFontBaked *bakedFont(const NativeRegion::Payload &payload)
{
  ImFont *font {payload.font};
  if(!font || !(payload.fontSize > 0.f))
    return nullptr;
  // the font may have been removed since: look for the pointer itself
  // before reading through it
  const ImFontAtlas *atlas {ImGui::GetIO().Fonts};
  if(!atlas || !atlas->Fonts.contains(font) || !atlas->Builder)
    return nullptr;

  const float size {ImGui::GetRoundedFontSize(payload.fontSize)},
              density {payload.fontDensity > 0.f ? payload.fontDensity : 1.f};
  const ImFontBaked *baked {font->LastBaked};
  if(!baked || baked->Size != size || baked->RasterizerDensity != density) {
    const ImGuiID id {ImFontAtlasBakedGetId(font->FontId, size, density)};
    baked = static_cast<const ImFontBaked *>(atlas->Builder->BakedMap.GetVoidPtr(id));
  }
  if(!baked || baked->WantDestroy || baked->OwnerFont != font)
    return nullptr;
  return baked;
}

// The glyph as ImFontBaked::FindGlyph would return it, without loading:
// null when it is not baked (nothing drawn; *advance says how far to move).
static const ImFontGlyph *bakedGlyph(const ImFontBaked &baked,
  const unsigned int c, float *advance)
{
  *advance = c < static_cast<unsigned int>(baked.IndexAdvanceX.Size) &&
    baked.IndexAdvanceX.Data[c] >= 0.f ? baked.IndexAdvanceX.Data[c] : baked.FallbackAdvanceX;
  if(c >= static_cast<unsigned int>(baked.IndexLookup.Size))
    return nullptr;
  const ImU16 index {baked.IndexLookup.Data[c]};
  if(index == GLYPH_UNUSED)
    return nullptr;
  const int at {index == GLYPH_NOT_FOUND ? baked.FallbackGlyphIndex : index};
  if(at < 0 || at >= baked.Glyphs.Size)
    return nullptr;
  return &baked.Glyphs.Data[at];
}

// ImFont::RenderText's glyph placement (no wrapping, no fine clip) over
// already-baked glyphs only.
static void paintText(NvkGui_RegionPainter *p, double x, double y,
  const unsigned int rgba, const char *text, const int len)
{
  if(!text || !p->payload)
    return;
  const char *end {len < 0 ? text + std::strlen(text) : text + len};
  const ImU32 col {Color::fromBigEndian(rgba)};
  if(text == end || !(col & IM_COL32_A_MASK))
    return;
  const ImFontBaked *baked {bakedFont(*p->payload)};
  if(!baked)
    return;

  ImDrawList *dl {p->drawList};
  const ImVec4 clip {dl->_CmdHeader.ClipRect};
  float px {static_cast<float>(x)}, py {static_cast<float>(y)};
  if(!p->payload->textNoPixelSnap && !(dl->Flags & ImDrawFlags_TextNoPixelSnap)) {
    px = IM_TRUNC(px);
    py = IM_TRUNC(py);
  }
  const float scale {p->payload->fontSize / baked->Size},
              lineHeight {baked->LineHeight}, originX {px};
  const ImU32 untinted {col | ~IM_COL32_A_MASK};

  for(const char *s {text}; s < end;) {
    if(py > clip.w)
      break;
    unsigned int c {static_cast<unsigned char>(*s)};
    if(c < 0x80)
      s += 1;
    else
      s += ImTextCharFromUtf8(&c, s, end);
    if(c == '\n') {
      px = originX;
      py += lineHeight;
      continue;
    }
    if(c == '\r')
      continue;

    float advance;
    const ImFontGlyph *glyph {bakedGlyph(*baked, c, &advance)};
    if(!glyph) {
      px += advance * scale;
      continue;
    }
    const float width {glyph->AdvanceX * scale};
    if(glyph->Visible) {
      const ImVec2 a {px + glyph->X0 * scale, py + glyph->Y0 * scale},
                   b {px + glyph->X1 * scale, py + glyph->Y1 * scale};
      if(a.x <= clip.z && b.x >= clip.x) {
        dl->PrimReserve(6, 4);
        dl->PrimRectUV(a, b, ImVec2(glyph->U0, glyph->V0),
          ImVec2(glyph->U1, glyph->V1), glyph->Colored ? untinted : col);
      }
    }
    px += width;
  }
}

static ImU32 col(const unsigned int rgba)
{
  return Color::fromBigEndian(rgba);
}

static const std::vector<ImVec2> &points(NvkGui_RegionPainter *painter,
  const double *xy, const int count)
{
  painter->points.resize(count > 0 ? count : 0);
  for(int i {}; i < count; ++i)
    painter->points[i] = ImVec2(xy[i * 2], xy[i * 2 + 1]);
  return painter->points;
}

static const NvkGui_RegionPaintApi g_paintApi {
  NVKGUI_NATIVE_REGION_ABI_VERSION,
  // line
  [](NvkGui_RegionPainter *p, double x1, double y1, double x2, double y2,
      unsigned int c, double thickness) {
    p->drawList->AddLine(ImVec2(x1, y1), ImVec2(x2, y2), col(c), thickness);
  },
  // polyline
  [](NvkGui_RegionPainter *p, const double *xy, int count, unsigned int c,
      int closed, double thickness) {
    const auto &pts {points(p, xy, count)};
    p->drawList->AddPolyline(pts.data(), count, col(c),
      thickness, closed ? ImDrawFlags_Closed : ImDrawFlags_None);
  },
  // rect
  [](NvkGui_RegionPainter *p, double x1, double y1, double x2, double y2,
      unsigned int c, double rounding, double thickness) {
    p->drawList->AddRect(ImVec2(x1, y1), ImVec2(x2, y2), col(c), rounding,
      thickness, ImDrawFlags_None);
  },
  // rectFilled
  [](NvkGui_RegionPainter *p, double x1, double y1, double x2, double y2,
      unsigned int c, double rounding) {
    p->drawList->AddRectFilled(ImVec2(x1, y1), ImVec2(x2, y2), col(c), rounding);
  },
  // rectFilledMultiColor
  [](NvkGui_RegionPainter *p, double x1, double y1, double x2, double y2,
      unsigned int ul, unsigned int ur, unsigned int lr, unsigned int ll) {
    p->drawList->AddRectFilledMultiColor(ImVec2(x1, y1), ImVec2(x2, y2),
      col(ul), col(ur), col(lr), col(ll));
  },
  // quadFilled
  [](NvkGui_RegionPainter *p, double x1, double y1, double x2, double y2,
      double x3, double y3, double x4, double y4, unsigned int c) {
    p->drawList->AddQuadFilled(ImVec2(x1, y1), ImVec2(x2, y2), ImVec2(x3, y3),
      ImVec2(x4, y4), col(c));
  },
  // circleFilled
  [](NvkGui_RegionPainter *p, double x, double y, double radius,
      unsigned int c) {
    p->drawList->AddCircleFilled(ImVec2(x, y), radius, col(c));
  },
  // convexPolyFilled
  [](NvkGui_RegionPainter *p, const double *xy, int count, unsigned int c) {
    const auto &pts {points(p, xy, count)};
    p->drawList->AddConvexPolyFilled(pts.data(), count, col(c));
  },
  // concavePolyFilled
  [](NvkGui_RegionPainter *p, const double *xy, int count, unsigned int c) {
    const auto &pts {points(p, xy, count)};
    p->drawList->AddConcavePolyFilled(pts.data(), count, col(c));
  },
  // pushClipRect
  [](NvkGui_RegionPainter *p, double x1, double y1, double x2, double y2) {
    p->drawList->PushClipRect(ImVec2(x1, y1), ImVec2(x2, y2), true);
  },
  // popClipRect
  [](NvkGui_RegionPainter *p) {
    // never pop the region's own rectangle (pushed before the drawer runs)
    if(p->drawList->_ClipRectStack.Size > 1)
      p->drawList->PopClipRect();
  },
  // text
  &paintText,
};

bool NativeRegion::paint(const Payload &payload, ImDrawList *drawList,
  const float pixelScale, std::vector<ImVec2> &points)
{
  if(payload.drawer < 0 || static_cast<size_t>(payload.drawer) >= g_drawers.size())
    return false;
  const Drawer &drawer {g_drawers[payload.drawer]};
  if(!drawer.func)
    return false;

  static const auto epoch {std::chrono::steady_clock::now()};
  const std::chrono::duration<double> time
    {std::chrono::steady_clock::now() - epoch};

  const NvkGui_RegionInfo info {
    payload.key,
    payload.min.x, payload.min.y, payload.max.x, payload.max.y,
    pixelScale, time.count(),
  };
  NvkGui_RegionPainter painter {drawList, points, &payload};
  return drawer.func(drawer.user, &info, &painter, &g_paintApi) != 0;
}

ImDrawList *NativeRegion::Compositor::expanded(const size_t index)
{
  while(m_expanded.size() <= index)
    m_expanded.push_back(std::make_unique<ImDrawList>(ImGui::GetDrawListSharedData()));
  return m_expanded[index].get();
}

void NativeRegion::Compositor::composite()
{
  restore();
  m_live = false;
  if(g_drawers.empty())
    return;

  if(!m_scratch)
    m_scratch = std::make_unique<ImDrawList>(ImGui::GetDrawListSharedData());

  const ImTextureRef atlas {ImGui::GetIO().Fonts->TexRef};
  size_t used {};
  for(ImGuiViewport *viewport : ImGui::GetPlatformIO().Viewports) {
    ImDrawData *drawData {viewport->DrawData};
    if(!drawData || !drawData->Valid)
      continue;

    const float scale {viewport->DpiScale};
    const Paint paint {[this, scale](const Payload &payload, ImDrawList *dl) {
      return NativeRegion::paint(payload, dl, scale, m_points);
    }};

    for(int i {}; i < drawData->CmdLists.Size; ++i) {
      ImDrawList *src {drawData->CmdLists[i]}, *out {expanded(used)};
      if(!expand(*src, *out, *m_scratch, atlas, paint, &m_live))
        continue;
      ++used;
      drawData->TotalVtxCount += out->VtxBuffer.Size - src->VtxBuffer.Size;
      drawData->TotalIdxCount += out->IdxBuffer.Size - src->IdxBuffer.Size;
      drawData->CmdLists[i] = out;
      m_swaps.push_back({drawData, i, src, out});
    }
  }
}

void NativeRegion::Compositor::restore()
{
  // a viewport destroyed since takes its draw data with it
  const auto alive {[](const ImDrawData *drawData) {
    for(const ImGuiViewport *viewport : ImGui::GetPlatformIO().Viewports) {
      if(viewport->DrawData == drawData)
        return true;
    }
    return false;
  }};

  for(const Swap &swap : m_swaps) {
    if(!alive(swap.drawData))
      continue;
    if(swap.index >= swap.drawData->CmdLists.Size)
      continue;
    ImDrawList *out {swap.drawData->CmdLists[swap.index]};
    if(out != swap.copy)
      continue; // rebuilt by Render since
    swap.drawData->TotalVtxCount -= out->VtxBuffer.Size - swap.original->VtxBuffer.Size;
    swap.drawData->TotalIdxCount -= out->IdxBuffer.Size - swap.original->IdxBuffer.Size;
    swap.drawData->CmdLists[swap.index] = swap.original;
  }
  m_swaps.clear();
}
