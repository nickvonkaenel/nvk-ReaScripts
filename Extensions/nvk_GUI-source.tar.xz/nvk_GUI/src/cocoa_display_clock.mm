/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "display_clock.hpp"

#include "context.hpp"

#include <atomic>
#include <chrono>
#include <CoreVideo/CoreVideo.h>
#include <dispatch/dispatch.h>

using Clock = std::chrono::steady_clock;

// how long the clock keeps ticking after the last request
constexpr auto IDLE_STOP {std::chrono::seconds {1}};

static CVDisplayLinkRef g_link;
static std::atomic<bool> g_tickPending, g_tornDown;
static Clock::time_point g_lastRequest; // main thread only

static void stop()
{
  if(g_link && CVDisplayLinkIsRunning(g_link))
    CVDisplayLinkStop(g_link);
}

static void tick() // main thread
{
  g_tickPending = false;
  if(g_tornDown)
    return;

  if(Clock::now() - g_lastRequest > IDLE_STOP) {
    stop();
    return;
  }

  Resource::foreach<Context>([](Context *ctx) { ctx->replay(); });
}

// display link thread: hand one tick at a time to the main thread, dropping
// vsyncs while the previous one is still waiting to run
static CVReturn onVsync(CVDisplayLinkRef, const CVTimeStamp *,
  const CVTimeStamp *, CVOptionFlags, CVOptionFlags *, void *)
{
  if(!g_tickPending.exchange(true))
    dispatch_async(dispatch_get_main_queue(), ^{ tick(); });
  return kCVReturnSuccess;
}

void DisplayClock::request()
{
  if(g_tornDown)
    return;

  g_lastRequest = Clock::now();

  if(!g_link) {
    if(CVDisplayLinkCreateWithActiveCGDisplays(&g_link) != kCVReturnSuccess) {
      g_link = nullptr;
      return;
    }
    CVDisplayLinkSetOutputCallback(g_link, &onVsync, nullptr);
  }

  if(!CVDisplayLinkIsRunning(g_link))
    CVDisplayLinkStart(g_link);
}

void DisplayClock::teardown()
{
  g_tornDown = true;
  if(g_link) {
    stop();
    CVDisplayLinkRelease(g_link);
    g_link = nullptr;
  }
}
