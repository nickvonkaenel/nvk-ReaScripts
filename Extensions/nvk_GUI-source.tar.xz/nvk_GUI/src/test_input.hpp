/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NVKGUI_TEST_INPUT_HPP
#define NVKGUI_TEST_INPUT_HPP

#include <imgui/imgui.h>

#include <vector>

struct ImGuiContext;

// Synthetic input a script queues for its own context (TestInject), so test
// harnesses can hover, click, drag, scroll and type without the system mouse
// or keyboard. Events go into ImGui's input queue in call order, in ImGui
// coordinates, and ImGui's trickling spreads them over frames as it does
// for real input.
//
// The first injection takes the context's input. From then on the real cursor
// is no longer polled, so the injected position (and any hover it causes)
// stays put while the person keeps using the computer. While a sequence is
// busy (an injection within BUSY_SECONDS), real button, wheel, key and text
// events for the context are dropped. Once it is idle, the person takes the
// context back by pressing a button or key in it, scrolling it, or moving the
// pointer over it; Release (or TestInject's "release") does the same from the
// script. Taking it back lifts every injected button and key still held.
class TestInput {
public:
  static constexpr double BUSY_SECONDS {0.5};

  bool owns() const { return m_owned; }
  bool busy(double now) const
    { return m_owned && now - m_lastInjection < BUSY_SECONDS; }

  void move(ImGuiContext *, ImGuiID viewport, ImVec2 position, double now);
  void button(ImGuiContext *, int button, bool down, double now);
  void wheel(ImGuiContext *, float horizontal, float vertical, double now);
  void key(ImGuiContext *, ImGuiKey, bool down, double now);
  void text(ImGuiContext *, const char *utf8, double now);
  void hold(ImGuiContext *, double now); // keeps a waiting sequence busy
  void release(ImGuiContext *);

  static bool validKey(ImGuiKey);

  // Focuses a window inside ImGui, at the start of a frame: the one named, or
  // with an empty name the frontmost root window, and that one only when none
  // of the context's windows has focus. Focus already in the window, one of
  // its popups or one of its children stays there (FocusWindow would close
  // the popups), and a window below an open modal is left alone.
  static void focus(ImGuiContext *, const char *window);

  // Gates for real input. They return whether the real event or cursor
  // position may reach ImGui; the first real press after a sequence goes idle
  // releases the context and passes through.
  bool acceptRealEvent(ImGuiContext *, bool press, double now);
  bool acceptRealCursor(ImGuiContext *, ImVec2 cursor, bool overContext,
    double now);

private:
  void take(ImGuiContext *, double now);

  bool m_owned {};
  double m_lastInjection {};
  bool m_haveCursor {};
  ImVec2 m_realCursor {};
  unsigned int m_buttons {};
  std::vector<ImGuiKey> m_keys;
};

#endif
