/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "frame_snapshot.hpp"

#include <imgui/imgui.h>
#include <cstring>

// One field order for capture and comparison. Avoid struct padding and retain
// exact equality: a hash collision must never leave stale pixels on screen.
template<typename Sink>
static bool visitFrame(const ImDrawData *drawData, Sink &&sink)
{
  if(!drawData || !drawData->Valid)
    return false;
  if(drawData->Textures) {
    for(const ImTextureData *tex : *drawData->Textures) {
      if(tex->Status != ImTextureStatus_OK || tex->WantDestroyNextFrame)
        return false;
    }
  }
  const auto value = [&sink](const auto &v) { return sink(&v, sizeof(v)); };
  if(!value(drawData->DisplayPos) || !value(drawData->DisplaySize) ||
      !value(drawData->FramebufferScale) || !value(drawData->CmdLists.Size))
    return false;
  for(const ImDrawList *list : drawData->CmdLists) {
    // Standard callbacks are backend-provided functions in 1.93. Conservatively
    // render every callback-bearing frame instead of assuming it is inert.
    for(const ImDrawCmd &cmd : list->CmdBuffer) {
      if(cmd.UserCallback)
        return false;
    }
    if(!value(list->VtxBuffer.Size) ||
        !sink(list->VtxBuffer.Data, list->VtxBuffer.size_in_bytes()) ||
        !value(list->IdxBuffer.Size) ||
        !sink(list->IdxBuffer.Data, list->IdxBuffer.size_in_bytes()) ||
        !value(list->CmdBuffer.Size))
      return false;
    for(const ImDrawCmd &cmd : list->CmdBuffer) {
      if(!value(cmd.ClipRect) || !value(cmd.TexRef._TexData) ||
          !value(cmd.TexRef._TexID) || !value(cmd.VtxOffset) ||
          !value(cmd.IdxOffset) || !value(cmd.ElemCount) || !value(cmd.UserCallback))
        return false;
    }
  }
  return true;
}

bool FrameSnapshot::capture(const ImDrawData *drawData)
{
  m_bytes.clear();
  const bool valid = visitFrame(drawData, [this](const void *data, const size_t size) {
    if(size) {
      const auto *first = static_cast<const unsigned char *>(data);
      m_bytes.insert(m_bytes.end(), first, first + size);
    }
    return true;
  });
  if(!valid)
    clear();
  return valid;
}

bool FrameSnapshot::matches(const ImDrawData *drawData) const
{
  size_t offset {};
  return visitFrame(drawData, [this, &offset](const void *data, const size_t size) {
    if(size > m_bytes.size() - offset)
      return false;
    if(size && std::memcmp(m_bytes.data() + offset, data, size))
      return false;
    offset += size;
    return true;
  }) && offset == m_bytes.size();
}
