/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/* C interface between nvk_GUI and the native extensions that paint native
 * regions (DrawList_AddNativeRegion). Plain C so other extensions can include
 * it without nvk_GUI's or Dear ImGui's headers.
 *
 * A drawer is registered once with NvkGui_RegisterNativeRegionDrawer. nvk_GUI
 * calls it on REAPER's main thread every time a window holding one of its
 * regions renders: on script frames, and between them at display rate while
 * the drawer reports live content. Coordinates are in the same screen space
 * as the script's draw list calls. Colors are 0xRRGGBBAA, as in scripts. */

#ifndef NVKGUI_NATIVE_REGION_ABI_H
#define NVKGUI_NATIVE_REGION_ABI_H

#ifdef __cplusplus
extern "C" {
#endif

/* 1: the shapes; 2: text. A table's version says which of its members
 * exist: a drawer must check it before calling a member a later version
 * added (an older nvk_GUI passes a shorter table). */
#define NVKGUI_NATIVE_REGION_ABI_VERSION 2
#define NVKGUI_NATIVE_REGION_ABI_SHAPES 1
#define NVKGUI_NATIVE_REGION_ABI_TEXT 2

typedef struct NvkGui_RegionPainter NvkGui_RegionPainter; /* opaque */

typedef struct NvkGui_RegionPaintApi {
  int version; /* NVKGUI_NATIVE_REGION_ABI_VERSION */

  void (*line)(NvkGui_RegionPainter *, double x1, double y1, double x2,
    double y2, unsigned int col, double thickness);
  /* xy holds count interleaved x, y pairs */
  void (*polyline)(NvkGui_RegionPainter *, const double *xy, int count,
    unsigned int col, int closed, double thickness);
  void (*rect)(NvkGui_RegionPainter *, double x1, double y1, double x2,
    double y2, unsigned int col, double rounding, double thickness);
  void (*rectFilled)(NvkGui_RegionPainter *, double x1, double y1, double x2,
    double y2, unsigned int col, double rounding);
  void (*rectFilledMultiColor)(NvkGui_RegionPainter *, double x1, double y1,
    double x2, double y2, unsigned int upperLeft, unsigned int upperRight,
    unsigned int lowerRight, unsigned int lowerLeft);
  void (*quadFilled)(NvkGui_RegionPainter *, double x1, double y1, double x2,
    double y2, double x3, double y3, double x4, double y4, unsigned int col);
  void (*circleFilled)(NvkGui_RegionPainter *, double x, double y,
    double radius, unsigned int col);
  void (*convexPolyFilled)(NvkGui_RegionPainter *, const double *xy, int count,
    unsigned int col);
  void (*concavePolyFilled)(NvkGui_RegionPainter *, const double *xy, int count,
    unsigned int col);
  /* intersected with the region's own clip rectangle */
  void (*pushClipRect)(NvkGui_RegionPainter *, double x1, double y1,
    double x2, double y2);
  void (*popClipRect)(NvkGui_RegionPainter *);

  /* Version 2 (NVKGUI_NATIVE_REGION_ABI_TEXT). UTF-8 text with its top
   * left at x, y (len bytes; -1 up to the terminating zero), in the font and
   * size current when the script added the region, as DrawList_AddText would
   * draw it there. Only glyphs already baked in the font atlas are drawn
   * (the script's frame drew the same strings); any other is skipped, as
   * baking one here would change the atlas between frames. */
  void (*text)(NvkGui_RegionPainter *, double x, double y, unsigned int col,
    const char *text, int len);
} NvkGui_RegionPaintApi;

typedef struct NvkGui_RegionInfo {
  double key;            /* the script's key argument */
  double x1, y1, x2, y2; /* the region rectangle */
  double pixelScale;     /* framebuffer pixels per coordinate unit */
  double time;           /* seconds, monotonic; same clock for every call */
} NvkGui_RegionInfo;

/* Paints one region. Returns nonzero while its content changes over time,
 * which keeps nvk_GUI redrawing the window between script frames; zero when
 * it would paint the same thing again until the script's next frame. */
typedef int (*NvkGui_RegionDrawer)(void *user, const NvkGui_RegionInfo *,
  NvkGui_RegionPainter *, const NvkGui_RegionPaintApi *);

#ifdef __cplusplus
}
#endif

#endif
