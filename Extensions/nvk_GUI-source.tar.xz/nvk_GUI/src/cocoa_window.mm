/* ReaImGui: ReaScript binding for Dear ImGui
 * Copyright (C) 2021-2025  Christian Fillion
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "cocoa_window.hpp"

#include "cocoa_events.hpp"
#include "cocoa_inject.hpp"
#include "cocoa_inputview.hpp"
#include "context.hpp"
#include "error.hpp"
#include "platform.hpp"
#include "renderer.hpp"

#include <algorithm>
#include <imgui/imgui_internal.h>
#include <objc/message.h>
#include <objc/runtime.h>
#include <reaper_plugin_secrets.h>

static_assert(__has_feature(objc_arc),
  "This file must be built with automatic reference counting enabled.");

constexpr char ALWAYS_ON_TOP_KEY {};

static bool isAlwaysOnTop(NSWindow *window)
{
  return !!objc_getAssociatedObject(window, &ALWAYS_ON_TOP_KEY);
}

@interface SWELLWindowOverride : NSWindow
- (NSRect)constrainFrameRect:(NSRect)frameRect toScreen:(NSScreen *)screen;
- (void)setLevel:(NSInteger)level;
@end

@implementation SWELLWindowOverride
- (NSRect)constrainFrameRect:(NSRect)frameRect toScreen:(NSScreen *)screen
{
  if(!CocoaInject::isTarget(self))
    return [super constrainFrameRect:frameRect toScreen:screen];

  // allow setPosition to move the window outside of the woring area
  return frameRect;
}

- (void)setLevel:(NSInteger)level
{
  // SWELL resets the level of every window owned by REAPER's main window
  // whenever the application is activated or deactivated. Always-on-top
  // windows keep floating above other applications through those resets.
  if(CocoaInject::isTarget(self) && isAlwaysOnTop(self))
    level = std::max<NSInteger>(level, NSFloatingWindowLevel);
  [super setLevel:level];
  Platform::windowsChanged(); // a level moves the window among the others
}
@end

static void setAlwaysOnTop(NSWindow *window, const bool alwaysOnTop)
{
  objc_setAssociatedObject(window, &ALWAYS_ON_TOP_KEY,
    alwaysOnTop ? @YES : nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

  // Private AppKit hook. SWELL's windows are plain NSWindows, which reject
  // NSWindowStyleMaskNonactivatingPanel; this gives them the same "clicking
  // doesn't activate the application" behavior (verified on macOS 15). Without
  // it the window still floats, but clicking on it brings REAPER forward.
  const SEL setPreventsActivation {@selector(_setPreventsActivation:)};
  if([window respondsToSelector:setPreventsActivation]) {
    const auto send {reinterpret_cast<void (*)(id, SEL, BOOL)>(objc_msgSend)};
    send(window, setPreventsActivation, alwaysOnTop);
  }

  if(alwaysOnTop) {
    [window setCollectionBehavior:NSWindowCollectionBehaviorCanJoinAllSpaces |
                                  NSWindowCollectionBehaviorFullScreenAuxiliary];
    [window setLevel:NSFloatingWindowLevel];
    return;
  }

  [window setCollectionBehavior:NSWindowCollectionBehaviorDefault];
  [window setLevel:NSNormalWindowLevel];

  // let SWELL put the window back at its owner's level + 1
  const auto send {reinterpret_cast<id (*)(id, SEL)>(objc_msgSend)};
  const SEL getOwner {@selector(swellGetOwner)},
            resetLevels {@selector(swellResetOwnedWindowLevels)};
  if(![window respondsToSelector:getOwner])
    return;
  if(id owner {send(window, getOwner)}; [owner respondsToSelector:resetLevels])
    send(owner, resetLevels);
}

CocoaWindow::CocoaWindow(ImGuiViewport *viewport, DockerHost *dockerHost)
  : Window {viewport, dockerHost}
{
}

CocoaWindow::~CocoaWindow()
{
}

void CocoaWindow::create()
{
  createSwellDialog();
  m_view = (__bridge NSView *)m_hwnd; // SWELL_hwndChild inherits from NSView
  m_inputView = [[InputView alloc] initWithWindow:this];

  NSWindow *window {[m_view window]};
  m_defaultStyleMask = [window styleMask];
  m_previousScale = m_viewport->DpiScale;
  m_previousFlags = ~m_viewport->Flags; // mark all as modified
  // imgui calls update() before show(), it will apply the flags

  try {
    m_renderer = m_ctx->rendererFactory()->create(this);
  }
  catch(const backend_error &) {
    destroy();
    throw;
  }

  if(!isDocked()) {
    CocoaInject::inject([SWELLWindowOverride class], window);

    // enable transparency
    [window setOpaque:NO];
    [window setBackgroundColor:[NSColor clearColor]]; // required when decorations are enabled
  }

  static __weak EventHandler *g_handler;
  if(g_handler)
    m_eventHandler = g_handler;
  else
    g_handler = m_eventHandler = [[EventHandler alloc] init];
}

void CocoaWindow::show()
{
  Window::show();
  [m_eventHandler watchView:m_view context:m_ctx];

  // Window::show's SW_SHOW made the window key (makeKeyAndOrderFront in
  // SWELL), but the InputView only becomes first responder one runloop
  // later via the WM_SETFOCUS handler's dispatch_async. Take keyboard
  // focus synchronously so that keys typed right after the window is
  // created (eg. via Present during the script's first defer callback)
  // reach the script instead of falling through to REAPER's main window.
  if(!isDocked() && !(m_viewport->Flags & ImGuiViewportFlags_NoFocusOnAppearing))
    setFocus();
}

void CocoaWindow::setPosition(ImVec2 pos)
{
  Platform::scalePosition(&pos, true);

  NSWindow *window {[m_view window]};
  const NSRect &content {[window contentRectForFrameRect:[window frame]]};
  const CGFloat titleBarHeight {[window frame].size.height - content.size.height};
  [window setFrameTopLeftPoint:NSMakePoint(pos.x, pos.y + titleBarHeight)];
}

void CocoaWindow::setSize(const ImVec2 size)
{
  // most scripts expect y=0 to be the top of the window, while Cocoa grows a
  // window from its bottom-left corner: put the top-left corner back where it
  // was. Measured from the window itself rather than reapplied from
  // m_viewport->Pos, which is a frame behind while the operating system is
  // moving the window (see StartWindowMove) and would drag it back under
  // the pointer at every resize.
  NSWindow *window {[m_view window]};
  const NSRect frame {[window frame]};
  const NSPoint topLeft
    {NSMakePoint(frame.origin.x, frame.origin.y + frame.size.height)};
  [window setContentSize:NSMakeSize(size.x, size.y)];
  [window setFrameTopLeftPoint:topLeft];
}

void CocoaWindow::setFocus()
{
  NSWindow *window {[m_view window]};
  [window makeKeyAndOrderFront:nil];
  [window makeFirstResponder:m_inputView];
}

bool CocoaWindow::hasFocus() const
{
  // m_hwnd temporarily has focus between ShowWindow and WM_SETFOCUS
  // returning true here in this case is important, otherwise
  // Context::updateFocus would misdetect no active windows when it's called
  // from EventHandler::windowDidResignKey
  const HWND focus {GetFocus()};
  return focus == (__bridge HWND)m_inputView || focus == m_hwnd;
}

void CocoaWindow::setTitle(const char *title)
{
  SetWindowText(m_hwnd, title);
}

void CocoaWindow::setAlpha(const float alpha)
{
  NSWindow *window {[m_view window]};
  [window setAlphaValue:alpha];
}

void CocoaWindow::update()
{
  releaseWheelModifiers();
  // restore keyboard focus to the input view when switching to our docker tab
  static bool no_wm_setfocus {atof(GetAppVersion()) < 6.53};
  if(no_wm_setfocus && GetFocus() == m_hwnd)
    setFocus();

  if(m_previousScale != m_viewport->DpiScale) {
    // resize macOS's GL objects when DPI changes (eg. moving to another screen)
    // NSViewFrameDidChangeNotification or WM_SIZE aren't sent
    m_renderer->setSize(m_viewport->Size);
    m_previousScale = m_viewport->DpiScale;
  }

  if(isDocked())
    return;

  const ImGuiViewportFlags flags {effectiveFlags()};
  const ImGuiViewportFlags diff {m_previousFlags ^ flags};
  m_previousFlags = flags;

  NSWindow *window {[m_view window]};

  // Compared against the window's actual state rather than through diff: a
  // popup opened from an always-on-top window inherits the bit from its first
  // update, when m_previousFlags (initialized from the inverted viewport
  // flags alone) would hide the change.
  const bool alwaysOnTop {(flags & ReaImGuiViewportFlags_AlwaysOnTop) != 0};
  if(alwaysOnTop != isAlwaysOnTop(window))
    setAlwaysOnTop(window, alwaysOnTop);

  if(diff & ImGuiViewportFlags_NoDecoration) {
    if(m_viewport->Flags & ImGuiViewportFlags_NoDecoration) {
      DetachWindowTopmostButton(m_hwnd, false);
      NSString *title {[window title]};
      [window setStyleMask:NSWindowStyleMaskBorderless]; // also clears the title
      [window setTitle:title];
    }
    else {
      [window setStyleMask:m_defaultStyleMask];
      AttachWindowTopmostButton(m_hwnd);
      // ask dear imgui to call setText again
      static_cast<ImGuiViewportP *>(m_viewport)->LastNameHash = 0;
    }
  }

  if(diff & ImGuiViewportFlags_TopMost) {
    // Using SWELL_SetWindowWantRaiseAmt instead of [NSWindow setLevel]
    // to automaticaly restore the level when the application regains focus.
    //
    // 0=normal/1=topmost as observed via a breakpoint when clicking on
    // AttachWindowTopmostButton's thumbstack button.
    const bool topmost {(flags & ImGuiViewportFlags_TopMost) != 0};
    SWELL_SetWindowWantRaiseAmt(m_hwnd, topmost);
  }

  // disable shadows under the window when WindowFlags_NoBackground is set
  // (shadows wouldn't be updated along with the contents until next resize)
  if(diff & ImGuiViewportFlags_NoRendererClear) {
    const bool opaque
      {(m_viewport->Flags & ImGuiViewportFlags_NoRendererClear) != 0};
    [window setHasShadow:opaque];
  }

  if(diff & ImGuiViewportFlags_NoInputs) {
    const bool hitTestTransparent
      {(m_viewport->Flags & ImGuiViewportFlags_NoInputs) != 0};
    [window setIgnoresMouseEvents:hitTestTransparent];
    Platform::windowsChanged(); // the window under the pointer may be another now
  }
}

float CocoaWindow::scaleFactor() const
{
  return [[m_view window] backingScaleFactor];
}

void CocoaWindow::setIME(ImGuiPlatformImeData *data)
{
  if(!data->WantVisible) {
    NSTextInputContext *inputContext {[m_inputView inputContext]};
    [inputContext discardMarkedText];
    [inputContext invalidateCharacterCoordinates];
  }

  ImVec2 pos {data->InputPos};
  Platform::scalePosition(&pos, true);
  pos.y -= data->InputLineHeight;

  [m_inputView setImePosition:NSMakePoint(pos.x, pos.y)];
}

std::optional<LRESULT> CocoaWindow::handleMessage
  (const unsigned int msg, WPARAM wParam, LPARAM)
{
  switch(msg) {
  case WM_SETFOCUS: { // REAPER v6.53+
    // Redirect focus to the input view after m_view gets it.
    // WM_SETFOCUS is sent from becomeFirstResponder,
    // m_view will gain focus right after this returns.
    //
    // Both makeFirstResponder and making the window key are required
    // for receiving key events right away without a click
    const bool focusOnAppearing
      {!(m_viewport->Flags & ImGuiViewportFlags_NoFocusOnAppearing)};
    if(focusOnAppearing || IsWindowVisible(m_hwnd)) {
      const HWND hwndCache {m_hwnd};
      dispatch_async(dispatch_get_main_queue(), ^{
        if(IsWindow(hwndCache)) // if we didn't get destroyed in the meantime
          setFocus();
      });
    }
    break;
  }
  case WM_SIZE:
    // SWELL does not send WM_MOVE when resizing moves the window origin
    m_viewport->PlatformRequestMove = true;
    break;
  case WM_MOUSEWHEEL:
  case WM_MOUSEHWHEEL:
    // [NSWindow setIgnoresMouseEvents] does not include mouse wheel events
    if(m_viewport->Flags & ImGuiViewportFlags_NoInputs) {
      HWND target {Platform::windowFromPoint(Platform::getCursorPos())};
      if(target && target != m_hwnd) {
        [(__bridge NSView *)target scrollWheel:[NSApp currentEvent]];
        return 0;
      }
    }
    break;
  case WM_RBUTTONUP:
    // Prevent DefWindowProc from emitting WM_CONTEXTMENU
    // when focus is lost before the right mouse button was released
    return 0;
  }

  return std::nullopt;
}

int CocoaWindow::handleAccelerator(MSG *msg)
{
  [[m_view window] sendEvent:[NSApp currentEvent]];
  return Accel::EatKeystroke;
}

bool CocoaWindow::platformStartMove()
{
  // performWindowDragWithEvent: wants the mouse event the drag continues
  // from, and the script asks from a timer callback with no event in flight.
  // The input view fulfills the request from its next mouseDragged event,
  // which is milliseconds away while the user is moving the mouse.
  if(@available(macOS 10.11, *)) {
    mouseUp(ImGuiMouseButton_Left);
    [m_inputView requestWindowDrag];
    return true;
  }
  return false;
}

ImGuiKeyChord Window::heldModifiers(const bool fromWheelEvent)
{
  // SWELL's GetAsyncKeyState omits Ctrl when right-click emulation is enabled

  struct Modifiers { CGEventFlags flag; ImGuiKey key; };
  constexpr Modifiers modifiers[] {
    {kCGEventFlagMaskControl,   ImGuiMod_Ctrl },
    {kCGEventFlagMaskCommand,   ImGuiMod_Super},
    {kCGEventFlagMaskShift,     ImGuiMod_Shift},
    {kCGEventFlagMaskAlternate, ImGuiMod_Alt  },
  };

  // A wheel event carries the modifiers held when it happened. It stays
  // NSApp's current event afterwards, so read it only while handling the wheel.
  NSEvent *event {[NSApp currentEvent]};
  const CGEventFlags state {fromWheelEvent && event.type == NSEventTypeScrollWheel
    ? static_cast<CGEventFlags>(event.modifierFlags)
    : CGEventSourceFlagsState(kCGEventSourceStateCombinedSessionState)};

  ImGuiKeyChord held {};
  for(const auto &modifier : modifiers) {
    if(state & modifier.flag)
      held |= modifier.key;
  }
  return held;
}
