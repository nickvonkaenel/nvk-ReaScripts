/* ReaImGui: ReaScript binding for Dear ImGui
 * Copyright (C) 2021-2025  Christian Fillion
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef REAIMGUI_CONTEXT_HPP
#define REAIMGUI_CONTEXT_HPP

#include "flat_set.hpp"
#ifdef __APPLE__
#  include "event_mouse.hpp"
#endif
#include "resource.hpp"
#include "test_input.hpp"

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include <imgui/imgui.h>

#ifdef _WIN32
#  include <windows.h>
#else
#  include <swell/swell-types.h>
#endif

class DockerList;
class Font;
class RendererFactory;
struct Subresource;
namespace NativeRegion { class Compositor; }

enum ConfigFlags {
  ReaImGuiConfigFlags_NoSavedSettings = 1<<20,
};

constexpr const char *REAIMGUI_PAYLOAD_TYPE_FILES {"_FILES"};

using FrameCallback = void (*)(Context *);

class Context final : public Resource {
public:
  static constexpr unsigned char SUBRESOURCE_TTL {120};

  static Context *current();
  static void clearCurrent();

  Context(const char *label, int userConfigFlags = ImGuiConfigFlags_None);
  ~Context();

  // public api
  int userConfigFlags() const;
  void setUserConfigFlags(int);
  void setFrameCallback(FrameCallback cb) { m_frameCallback = cb; }
  // Repaints this context's windows with fresh native region paint between
  // script frames, if any region reported live content (DisplayClock).
  void replay();
  void attach(Resource *);
  void detach(Resource *);
  bool isAttached(Resource *) const;
  bool usesSharedAtlas() const;

  template<typename T>
  T *touch(Resource *r) { return static_cast<T *>(touch<void>(r)); }
  ImTextureData *createTexture();

  std::vector<ImVec2> &drawPoints() { return m_drawPoints; }

  // api helpers
  void setCurrent();
  bool enterFrame();
  void present();

  // for backends
  void mouseInput(int button, bool down);
#ifdef __APPLE__
  void mousePosition(ImGuiViewport *, ImVec2 nativePosition);
#endif
  void mouseWheel(bool horizontal, float delta);
  void keyInput(ImGuiKey key, bool down);
  void charInput(unsigned int);
  void charInputUTF16(ImWchar16);
  void beginDrag(std::vector<std::string> &&);
  void beginDrag(HDROP);
  void endDrag(bool drop);
  void updateFocus();
  void enableViewports(bool enable);
  void invalidateViewportsPos();

  ImGuiIO &IO();

  // nvk_GUI: with error recovery on, ImGui's recoverable errors are kept here
  // instead of ending the context. The first message waits until taken.
  void setErrorRecovery(bool enable);
  void recordRecoveredError(const char *message);
  const char *takeRecoveredError();

  // nvk_GUI: synthetic input queued by a script (TestInject), in ImGui
  // coordinates. See TestInput for how it shares the context with real input.
  void testMove(ImVec2 position);
  void testButton(int button, bool down);
  void testWheel(float horizontal, float vertical);
  void testKey(ImGuiKey key, bool down);
  void testText(const char *utf8);
  void testFocus(const char *window);
  void testHold();
  void testRelease();

  ImGuiStyle &style();
  DockerList &dockers() { return *m_dockers; }
  HCURSOR cursor() const { return m_cursor; }
  ImGuiContext *imgui() const { return m_imgui.get(); }
  RendererFactory *rendererFactory() const { return m_rendererFactory.get(); }
  std::string screensetKey() const;
  const char *name() const { return m_name.c_str(); }
  const auto &draggedFiles() const { return m_draggedFiles; }

  bool attachable(const Context *) const override { return false; }

protected:
  bool heartbeat() override;

private:
  std::vector<ImVec2> m_drawPoints;
  std::string m_recoveredError, m_takenError;
  unsigned int m_recoveredCount {};
  static LRESULT screensetProc(const int action, const char *id,
    void *user, void *param, int paramSize);

  bool beginFrame();
  bool endFrame(bool render);

  void updateFrameInfo();
  void updateCursor();
  void updateMouseData();
  void updateSettings();
  void updateDragDrop();
  void updateSubresources();
  void cleanupTextures();

  ImGuiViewport *viewportUnder(ImVec2) const;
  ImGuiViewport *focusedViewport() const;
  ImGuiViewport *viewportAt(ImVec2) const;
  void applyTestFocus();
  void dragSources();
  void clearFocus();
  bool isAnyKeyDown() const;

  void loadScreenset(const char *data, unsigned long);
  long saveScreenset(char *data, unsigned long);

  ImGuiID m_id;
#ifdef __APPLE__
  EventMouseInput m_eventMouse;
#endif
  TestInput m_testInput;
  std::string m_testFocus;
  bool m_testFocusPending {};
  char m_stateFlags;
  HCURSOR m_cursor;
  FrameCallback m_frameCallback;
  std::chrono::time_point<std::chrono::steady_clock> m_lastFrame; // monotonic
  std::vector<std::string> m_draggedFiles;
  FlatSet<Resource *> m_attachments;
  std::vector<Subresource> m_subresources;
  std::string m_name, m_iniFilename;

  struct ContextDeleter { void operator()(ImGuiContext *); };
  std::unique_ptr<ImGuiContext, ContextDeleter> m_imgui;
  std::unique_ptr<DockerList> m_dockers;
  std::unique_ptr<RendererFactory> m_rendererFactory;
  Font *m_font;
  std::unique_ptr<NativeRegion::Compositor> m_regions;
  bool m_liveRegions {};
};

template<> void *Context::touch(Resource *);

API_REGISTER_OBJECT_TYPE(Context);
API_REGISTER_TYPE(FrameCallback, "NvkGui_FrameCallback");

#endif
