/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef REAIMGUI_TIMER_RATE_HPP
#define REAIMGUI_TIMER_RATE_HPP

#include <string_view>
#include <vector>

// REAPER's "misc timer" (0x29a on the main window) runs deferred ReaScripts
// and extension timers, so it sets every script's frame rate, nvk_GUI's
// included. Settings::TimerRate optionally re-arms it at a faster interval.
// That speeds up every script and extension in REAPER, so it is opt-in.
//
// The interval REAPER runs at before nvk_GUI changes anything is measured over
// the first ticks after load. That value is what "REAPER default" restores,
// including when another extension (reaper_60fps) already changed it.
namespace TimerRate {
  // Rates in Hz offered on this platform, after 0 (REAPER default).
  const std::vector<int> &choices();
  bool isChoice(int hz);

  void setup();
  void teardown();
  void apply(); // re-arm the timer for Settings::TimerRate

  // Interval REAPER ran at before nvk_GUI changed it, 0 until measured.
  int baselineIntervalMs();
  // Whether a known third-party extension that re-arms the timer is loaded.
  bool foreignOverrideLoaded();

  // Exposed for tests.
  int intervalMs(int hz);
  int medianIntervalMs(std::vector<double> intervals);
  bool isForeignOverrideModule(std::string_view path);
}

#endif
