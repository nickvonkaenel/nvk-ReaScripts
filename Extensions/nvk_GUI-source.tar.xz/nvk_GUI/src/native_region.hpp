/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef REAIMGUI_NATIVE_REGION_HPP
#define REAIMGUI_NATIVE_REGION_HPP

#include "native_region_abi.h"

#include <functional>
#include <imgui/imgui.h>
#include <memory>
#include <vector>

// Rectangles of a script's draw list painted by a native extension's drawer
// (DrawList_AddNativeRegion), so they can be repainted without the script.
//
// The script's draw list only holds a marker: an AddCallback whose payload
// names the drawer. Before a viewport renders, each draw list holding markers
// is copied with every marker replaced by the drawer's freshly painted
// commands. The painted vertices and indices are appended to the copy and
// addressed through VtxOffset/IdxOffset, which every renderer honors, so the
// renderers need no changes and the script's own draw lists stay untouched for
// the next composite.
namespace NativeRegion {
  struct Payload {
    int drawer;
    double key;
    ImVec2 min, max;
    // the font and size DrawList_AddText would use where the region was
    // added, for the painter's text (never dereferenced before checking the
    // font is still in the current context's atlas)
    ImFont *font;
    float fontSize, fontDensity;
    bool textNoPixelSnap;
  };

  int registerDrawer(const char *name, NvkGui_RegionDrawer, void *user);
  int findDrawer(const char *name); // -1 if none is registered by that name

  // records a region in the draw list; false if the drawer is unknown
  bool add(ImDrawList *, int drawer, double key, ImVec2 min, ImVec2 max);

  // Paints one region into the draw list (already clipped to the region and
  // bound to the font atlas texture). Returns whether its content is live.
  using Paint = std::function<bool (const Payload &, ImDrawList *)>;

  // Copies src into out with every marker replaced by its painted commands.
  // Returns false (leaving out untouched) when src holds no marker.
  bool expand(const ImDrawList &src, ImDrawList &out, ImDrawList &scratch,
    ImTextureRef atlas, const Paint &, bool *live);

  // calls the registered drawer through the C painter table
  bool paint(const Payload &, ImDrawList *, float pixelScale, std::vector<ImVec2> &points);

  // Per-context composite of every viewport's draw data. Requires the
  // context to be current.
  class Compositor {
  public:
    // Swaps in expanded copies of the draw lists holding markers. They stay
    // in place until the next call, as some renderers (Cocoa OpenGL) draw
    // after RenderWindow returns.
    void composite();
    // points the draw data back at the script's own draw lists where it still
    // holds our copies (Render rebuilds it each frame); context must be current
    void restore();

    // whether any region painted by the last composite() reported live content
    bool live() const { return m_live; }

  private:
    struct Swap {
      ImDrawData *drawData;
      int index;
      ImDrawList *original, *copy;
    };

    ImDrawList *expanded(size_t index);

    std::vector<std::unique_ptr<ImDrawList>> m_expanded;
    std::unique_ptr<ImDrawList> m_scratch;
    std::vector<Swap> m_swaps;
    std::vector<ImVec2> m_points;
    bool m_live {};
  };
}

#endif
