/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef REAIMGUI_DRAW_BATCH_HPP
#define REAIMGUI_DRAW_BATCH_HPP

#include <cstddef>
#include <imgui/imgui.h>

// Many plain primitives in one call, for draw-heavy views that would otherwise
// pay the script bridge once per primitive. Each one goes through the same
// ImDrawList call, with the same arguments, that DrawList_AddLine,
// DrawList_AddRectFilled or DrawList_AddRectFilledMultiColor would make for it,
// in the order given.
namespace DrawBatch {
  // `coords` holds x1,y1,x2,y2 for each line. A trailing partial group is ignored.
  inline void addLines(ImDrawList *drawList, const double *coords,
    const size_t count, const ImU32 col, const float thickness)
  {
    for(size_t i {}; i + 3 < count; i += 4) {
      drawList->AddLine(ImVec2(coords[i], coords[i + 1]),
        ImVec2(coords[i + 2], coords[i + 3]), col, thickness);
    }
  }

  // `coords` holds min_x,min_y,max_x,max_y for each rectangle, filled without
  // rounding. A trailing partial group is ignored.
  inline void addRectsFilled(ImDrawList *drawList, const double *coords,
    const size_t count, const ImU32 col)
  {
    for(size_t i {}; i + 3 < count; i += 4) {
      drawList->AddRectFilled(ImVec2(coords[i], coords[i + 1]),
        ImVec2(coords[i + 2], coords[i + 3]), col);
    }
  }

  // `coords` holds min_x,min_y,max_x,max_y for each rectangle, every one
  // filled with the same four corner colors. A trailing partial group is ignored.
  inline void addRectsFilledMultiColor(ImDrawList *drawList,
    const double *coords, const size_t count, const ImU32 colUprLeft,
    const ImU32 colUprRight, const ImU32 colBotRight, const ImU32 colBotLeft)
  {
    for(size_t i {}; i + 3 < count; i += 4) {
      drawList->AddRectFilledMultiColor(ImVec2(coords[i], coords[i + 1]),
        ImVec2(coords[i + 2], coords[i + 3]),
        colUprLeft, colUprRight, colBotRight, colBotLeft);
    }
  }
}

#endif
