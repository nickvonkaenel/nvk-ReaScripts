/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "display_clock.hpp"

#include "context.hpp"
#include "import.hpp"
#include "window.hpp"

#include <atlbase.h>
#include <atomic>
#include <chrono>
#include <dxgi.h>
#include <thread>

using Clock = std::chrono::steady_clock;

// how long the clock keeps ticking after the last request
constexpr auto IDLE_STOP {std::chrono::seconds {1}};
// without a display to wait on (remote sessions), about 120 ticks a second
constexpr auto FALLBACK_INTERVAL {std::chrono::milliseconds {8}};
constexpr UINT WM_DISPLAY_TICK {WM_APP + 0x31};
constexpr wchar_t CLASS_NAME[] {L"nvk_gui_display_clock"};

static HWND g_window;
static std::thread g_thread;
static std::atomic<bool> g_running, g_tickPending, g_tornDown;
static std::atomic<Clock::rep> g_lastRequest;

static LRESULT CALLBACK windowProc(HWND hwnd, const UINT msg,
  const WPARAM wParam, const LPARAM lParam)
{
  if(msg != WM_DISPLAY_TICK)
    return DefWindowProcW(hwnd, msg, wParam, lParam);

  g_tickPending = false;
  if(!g_tornDown)
    Resource::foreach<Context>([](Context *ctx) { ctx->replay(); });
  return 0;
}

// the output windows are most likely on; DXGI waits on one output's vblank
static CComPtr<IDXGIOutput> primaryOutput()
{
  static FuncImport<decltype(CreateDXGIFactory1)>
    _CreateDXGIFactory1 {L"dxgi", "CreateDXGIFactory1"};
  CComPtr<IDXGIFactory1> factory;
  CComPtr<IDXGIAdapter1> adapter;
  CComPtr<IDXGIOutput> output;
  if(_CreateDXGIFactory1 && SUCCEEDED(_CreateDXGIFactory1(IID_PPV_ARGS(&factory))) &&
      SUCCEEDED(factory->EnumAdapters1(0, &adapter)))
    adapter->EnumOutputs(0, &output);
  return output;
}

// worker thread: one tick per vblank, handed to the main thread one at a time
static void run()
{
  CComPtr<IDXGIOutput> output {primaryOutput()};
  while(!g_tornDown) {
    const Clock::time_point last {Clock::duration {g_lastRequest.load()}};
    if(Clock::now() - last > IDLE_STOP)
      break;
    if(!output || FAILED(output->WaitForVBlank()))
      std::this_thread::sleep_for(FALLBACK_INTERVAL);
    if(!g_tickPending.exchange(true))
      PostMessageW(g_window, WM_DISPLAY_TICK, 0, 0);
  }
  g_running = false;
}

static bool createWindow()
{
  WNDCLASSW windowClass {};
  windowClass.lpfnWndProc   = &windowProc;
  windowClass.hInstance     = Window::s_instance;
  windowClass.lpszClassName = CLASS_NAME;
  RegisterClassW(&windowClass);
  g_window = CreateWindowExW(0, CLASS_NAME, L"", 0, 0, 0, 0, 0,
    HWND_MESSAGE, nullptr, Window::s_instance, nullptr);
  return g_window != nullptr;
}

void DisplayClock::request()
{
  if(g_tornDown)
    return;

  g_lastRequest = Clock::now().time_since_epoch().count();

  if(!g_window && !createWindow())
    return;

  if(!g_running.exchange(true)) {
    if(g_thread.joinable())
      g_thread.join(); // the previous run has stopped (idle) or is stopping
    g_thread = std::thread {&run};
  }
}

void DisplayClock::teardown()
{
  g_tornDown = true;
  if(g_thread.joinable())
    g_thread.join(); // returns within one vblank or fallback interval
  if(g_window) {
    DestroyWindow(g_window);
    g_window = nullptr;
    UnregisterClassW(CLASS_NAME, Window::s_instance);
  }
}
