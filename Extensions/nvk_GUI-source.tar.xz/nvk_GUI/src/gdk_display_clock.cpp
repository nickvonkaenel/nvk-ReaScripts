/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "display_clock.hpp"

#include "context.hpp"

#include <algorithm>
#include <chrono>
#include <gdk/gdk.h>

using Clock = std::chrono::steady_clock;

// how long the clock keeps ticking after the last request
constexpr auto IDLE_STOP {std::chrono::seconds {1}};
// when the monitor does not report its rate
constexpr int FALLBACK_HZ {60};

static guint g_source;
static Clock::time_point g_lastRequest;
static bool g_tornDown;

// Docked windows draw into REAPER's own window, which has no frame clock of
// its own, so the clock is a main-loop timer at the primary monitor's rate.
static int refreshHz()
{
  GdkDisplay *display {gdk_display_get_default()};
  if(!display)
    return FALLBACK_HZ;
  GdkMonitor *monitor {gdk_display_get_primary_monitor(display)};
  if(!monitor && gdk_display_get_n_monitors(display) > 0)
    monitor = gdk_display_get_monitor(display, 0);
  const int milliHz {monitor ? gdk_monitor_get_refresh_rate(monitor) : 0};
  return milliHz >= 1000 ? (milliHz + 500) / 1000 : FALLBACK_HZ;
}

static gboolean tick(gpointer)
{
  if(g_tornDown || Clock::now() - g_lastRequest > IDLE_STOP) {
    g_source = 0;
    return G_SOURCE_REMOVE;
  }
  Resource::foreach<Context>([](Context *ctx) { ctx->replay(); });
  return G_SOURCE_CONTINUE;
}

void DisplayClock::request()
{
  if(g_tornDown)
    return;

  g_lastRequest = Clock::now();

  if(!g_source) {
    const guint interval {static_cast<guint>(std::max(1, 1000 / refreshHz()))};
    g_source = g_timeout_add_full(G_PRIORITY_DEFAULT, interval, &tick, nullptr, nullptr);
  }
}

void DisplayClock::teardown()
{
  g_tornDown = true;
  if(g_source) {
    g_source_remove(g_source);
    g_source = 0;
  }
}
