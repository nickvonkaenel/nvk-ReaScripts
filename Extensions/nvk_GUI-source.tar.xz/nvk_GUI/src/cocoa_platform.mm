/* ReaImGui: ReaScript binding for Dear ImGui
 * Copyright (C) 2021-2025  Christian Fillion
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "platform.hpp"

#include "cocoa_window.hpp"

#include <AppKit/AppKit.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <vector>
#include <imgui/imgui.h>
#include <reaper_plugin_functions.h>

static HWND g_fakeCapture;

void Platform::install()
{
  // Temprarily enable repeat character input
  // WARNING: this is application-wide!
  NSUserDefaults *defaults {[NSUserDefaults standardUserDefaults]};
  [defaults registerDefaults:@{@"ApplePressAndHoldEnabled":@NO}];

  ImGuiIO &io {ImGui::GetIO()};
  io.BackendPlatformName = "reaper_imgui_cocoa";
}

Window *Platform::createWindow(ImGuiViewport *viewport, DockerHost *dockerHost)
{
  return new CocoaWindow {viewport, dockerHost};
}

namespace {
// Shared by all contexts. Display/Space notifications invalidate immediately;
// a short fallback poll also catches work-area changes such as Dock auto-hide.
class MonitorCache {
public:
  MonitorCache()
  {
    m_displayObserver = [[NSNotificationCenter defaultCenter]
      addObserverForName:NSApplicationDidChangeScreenParametersNotification
      object:nil queue:nil usingBlock:^(NSNotification *) { m_dirty = true; }];
    m_spaceObserver = [[[NSWorkspace sharedWorkspace] notificationCenter]
      addObserverForName:NSWorkspaceActiveSpaceDidChangeNotification
      object:nil queue:nil usingBlock:^(NSNotification *) { m_dirty = true; }];
  }
  ~MonitorCache()
  {
    [[NSNotificationCenter defaultCenter] removeObserver:m_displayObserver];
    [[[NSWorkspace sharedWorkspace] notificationCenter] removeObserver:m_spaceObserver];
  }
  void update(ImVector<ImGuiPlatformMonitor> &out)
  {
    const auto now = std::chrono::steady_clock::now();
    if(m_dirty.exchange(false) || now - m_updated >= std::chrono::milliseconds(500)) {
      m_updated = now;
      m_monitors.clear();
      NSArray<NSScreen *> *screens = [NSScreen screens];
      if(screens.count == 0) {
        m_dirty = true;
        return; // keep a context's previous usable geometry
      }
      const CGFloat mainHeight = screens[0].frame.size.height;
      for(NSScreen *screen in screens) {
        const NSRect frame = screen.frame, workFrame = screen.visibleFrame;
        ImGuiPlatformMonitor monitor {};
        monitor.MainPos = ImVec2(frame.origin.x, mainHeight - frame.origin.y - frame.size.height);
        monitor.MainSize = ImVec2(frame.size.width, frame.size.height);
        monitor.WorkPos = ImVec2(workFrame.origin.x, mainHeight - workFrame.origin.y - workFrame.size.height);
        monitor.WorkSize = ImVec2(workFrame.size.width, workFrame.size.height);
        monitor.DpiScale = screen.backingScaleFactor;
        m_monitors.push_back(monitor);
      }
    }
    out.resize(static_cast<int>(m_monitors.size()));
    std::copy(m_monitors.begin(), m_monitors.end(), out.Data);
  }
private:
  id m_displayObserver, m_spaceObserver;
  std::atomic<bool> m_dirty {true};
  std::chrono::steady_clock::time_point m_updated {};
  std::vector<ImGuiPlatformMonitor> m_monitors;
};
}

void Platform::updateMonitors()
{
  static MonitorCache cache;
  cache.update(ImGui::GetPlatformIO().Monitors);
}

ImVec2 Platform::getCursorPos()
{
  // SWELL's GetCursorPos returns Y from 0-1080 instead of 0-1079 on a 1080p
  // monitor. Doing ceil(Y) - 1 here to workaround that.
  const NSPoint loc {[NSEvent mouseLocation]};
  return {floorf(loc.x), ceilf(loc.y) - 1};
}

void Platform::scalePosition(ImVec2 *pos, bool, const ImGuiViewport *)
{
  pos->y = ImGui::GetPlatformIO().Monitors[0].MainSize.y - 1 - pos->y;
}

namespace {
// Which window is under a point is the window server's to say: a round trip
// of about 0.1 ms that took 2 to 4 ms on two frames in five when measured.
// Every context asks once a frame while the pointer is over one of its
// windows, usually with the pointer at rest.
//
// The answer for one point is kept until something that could change it
// happens in this application: an event it handles (a click, a key, the
// wheel, pointer movement it is told of), any of its windows moving, resizing,
// showing, hiding, closing or taking or losing key, a menu opening or closing,
// one of our own windows changing its level or whether it takes the mouse, or
// the application or another one becoming active. Another application can
// still change its windows above a resting pointer without any of that
// reaching us, so a kept answer is also asked again after a tenth of a second.
// Only what is under a still pointer waits that long; input goes through the
// events above, which ask afresh.
class PointerHit {
public:
  PointerHit()
  {
    const auto invalidate {^(NSNotification *) { m_valid = false; }};
    m_observers = [NSMutableArray array];
    m_workspaceObservers = [NSMutableArray array];
    NSNotificationCenter *center {[NSNotificationCenter defaultCenter]};
    for(NSNotificationName name : {
      NSWindowDidMoveNotification, NSWindowDidResizeNotification,
      NSWindowWillCloseNotification, NSWindowDidBecomeKeyNotification,
      NSWindowDidResignKeyNotification, NSWindowDidBecomeMainNotification,
      NSWindowDidResignMainNotification, NSWindowDidMiniaturizeNotification,
      NSWindowDidDeminiaturizeNotification, NSWindowDidChangeScreenNotification,
      NSWindowDidChangeOcclusionStateNotification,
      NSWindowDidEnterFullScreenNotification, NSWindowDidExitFullScreenNotification,
      NSMenuDidBeginTrackingNotification, NSMenuDidEndTrackingNotification,
      NSApplicationDidBecomeActiveNotification,
      NSApplicationDidResignActiveNotification,
      NSApplicationDidHideNotification, NSApplicationDidUnhideNotification,
      NSApplicationDidChangeScreenParametersNotification,
    })
      [m_observers addObject:
        [center addObserverForName:name object:nil queue:nil usingBlock:invalidate]];
    NSNotificationCenter *workspace {[[NSWorkspace sharedWorkspace] notificationCenter]};
    for(NSNotificationName name : {
      NSWorkspaceDidActivateApplicationNotification,
      NSWorkspaceDidDeactivateApplicationNotification,
      NSWorkspaceDidHideApplicationNotification,
      NSWorkspaceDidUnhideApplicationNotification,
      NSWorkspaceDidLaunchApplicationNotification,
      NSWorkspaceDidTerminateApplicationNotification,
      NSWorkspaceActiveSpaceDidChangeNotification,
    })
      [m_workspaceObservers addObject:
        [workspace addObserverForName:name object:nil queue:nil usingBlock:invalidate]];
    m_monitor = [NSEvent addLocalMonitorForEventsMatchingMask:NSEventMaskAny
      handler:^NSEvent *(NSEvent *event) { m_valid = false; return event; }];
  }

  ~PointerHit()
  {
    for(id observer in m_observers)
      [[NSNotificationCenter defaultCenter] removeObserver:observer];
    for(id observer in m_workspaceObservers)
      [[[NSWorkspace sharedWorkspace] notificationCenter] removeObserver:observer];
    if(m_monitor)
      [NSEvent removeMonitor:m_monitor];
  }

  void invalidate() { m_valid = false; }

  NSInteger windowNumberAt(const NSPoint point)
  {
    const auto now {std::chrono::steady_clock::now()};
    if(!m_valid || point.x != m_point.x || point.y != m_point.y ||
        now - m_asked >= std::chrono::milliseconds(100)) {
      m_number = [NSWindow windowNumberAtPoint:point belowWindowWithWindowNumber:0];
      m_point = point;
      m_asked = now;
      m_valid = true;
    }
    return m_number;
  }

private:
  NSMutableArray *m_observers, *m_workspaceObservers;
  id m_monitor {};
  // Cleared from whichever thread posts one of the notifications.
  std::atomic<bool> m_valid {false};
  NSPoint m_point {};
  NSInteger m_number {};
  std::chrono::steady_clock::time_point m_asked {};
};

PointerHit &pointerHit()
{
  static PointerHit hit;
  return hit;
}
}

void Platform::windowsChanged()
{
  pointerHit().invalidate();
}

HWND Platform::windowFromPoint(const ImVec2 nativePoint)
{
  NSPoint point {NSMakePoint(nativePoint.x, nativePoint.y)};
  const NSInteger windowNumber {pointerHit().windowNumberAt(point)};
  NSWindow *window {[NSApp windowWithWindowNumber:windowNumber]};
  if(!window)
    return nullptr;

  NSView *view {[window contentView]};
  if(!view || ![view respondsToSelector:@selector(onSwellMessage:p1:p2:)])
    return nullptr;

  point = [window convertScreenToBase:point];
  if(NSView *childView {[view hitTest:point]})
    view = childView;

  return (__bridge HWND)view;
}

bool Platform::windowMayContainPoint(HWND hwnd, const ImVec2 nativePoint)
{
  NSView *view {(__bridge NSView *)hwnd};
  if(![view isKindOfClass:[NSView class]])
    return true;

  NSWindow *window {[view window]};
  if(!window)
    return false; // hit testing starts from a window's content view

  // One point wider than the view on every side, so that rounding can only
  // cost a query and never lose a hit.
  const NSRect frame {NSInsetRect(
    [window convertRectToScreen:[view convertRect:[view bounds] toView:nil]],
    -1, -1)};
  return NSPointInRect(NSMakePoint(nativePoint.x, nativePoint.y), frame);
}

float Platform::scaleForWindow(HWND hwnd)
{
  return [[(__bridge NSView *)hwnd window] backingScaleFactor];
}

@interface NSCursor (Undocumented)
+ (NSCursor *)_windowResizeNorthWestSouthEastCursor;
+ (NSCursor *)_windowResizeNorthEastSouthWestCursor;
+ (NSCursor *)_windowResizeNorthSouthCursor;
+ (NSCursor *)_windowResizeEastWestCursor;
+ (NSCursor *)busyButClickableCursor;
@end

HCURSOR Platform::getCursor(const ImGuiMouseCursor cur)
{
  switch(cur) {
  case ImGuiMouseCursor_None:
    static NSCursor *blank {
      [[NSCursor alloc] initWithImage:[[NSImage alloc]initWithSize:NSMakeSize(1, 1)]
                              hotSpot:NSMakePoint(0, 0)]
    };
    return (__bridge HCURSOR)blank;
  case ImGuiMouseCursor_ResizeAll:
    static HCURSOR bm {LoadCursor(nullptr, IDC_SIZEALL)};
    return bm;
  }

  static NSCursor * const cursors[ImGuiMouseCursor_COUNT] {
    [NSCursor arrowCursor],
    [NSCursor IBeamCursor],
    nullptr, // ResizeAll
    [NSCursor _windowResizeNorthSouthCursor],
    [NSCursor _windowResizeEastWestCursor],
    [NSCursor _windowResizeNorthEastSouthWestCursor],
    [NSCursor _windowResizeNorthWestSouthEastCursor],
    [NSCursor pointingHandCursor],
    [NSCursor busyButClickableCursor],
    [NSCursor busyButClickableCursor],
    [NSCursor operationNotAllowedCursor],
  };

  return (__bridge HCURSOR)cursors[cur];
}

// Not using SWELL capture to fix keyboard input when the REAPER setting
// "Allow keyboard commands when mouse-editing" is disabled in
// Preferences > General > Advanced UI tweaks. Otherwise REAPER would skip
// invoking accelerator callbacks (and not send WM_KEY* either).
//
// Capture behavior is implemented by [EventHandler appMouseEvent].
HWND Platform::getCapture()
{
  return g_fakeCapture;
}

void Platform::setCapture(HWND hwnd)
{
  g_fakeCapture = hwnd;
}

void Platform::releaseCapture()
{
  g_fakeCapture = nullptr;
}

bool Platform::modalActive()
{
  // SWELL runs REAPER's modal dialogs and alerts in an AppKit modal session,
  // which also disables the main window. Both are cheap every frame.
  if([NSApp modalWindow])
    return true;
  HWND main {GetMainHwnd()};
  return main && !IsWindowEnabled(main);
}

bool Platform::isAppActive()
{
  return [NSApp isActive];
}
