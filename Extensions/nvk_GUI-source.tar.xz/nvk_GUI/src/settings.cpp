/* ReaImGui: ReaScript binding for Dear ImGui
 * Copyright (C) 2021-2025  Christian Fillion
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#define SETTINGS_IMPLEMENT
#include "settings.hpp"

#include "action.hpp"
#include "dialog.hpp"
#include "localize.hpp"
#include "renderer.hpp"
#include "timer_rate.hpp"
#include "win32_unicode.hpp"
#include "window.hpp"

#include <algorithm>
#include <cmath>
#include <optional>
#include <string>
#include <reaper_plugin.h>
#include <reaper_plugin_functions.h>
#include <reaper_plugin_secrets.h>
#include <variant>
#include <WDL/wdltypes.h> // WDL_DLGRET
#include <WDL/wingui/wndsize.h>

#define L10N(str) __localizeFunc(str, "NVKGUI_DLG_100", 0)

template<typename T>
struct Setting;

struct Checkbox {
  enum Flags { None = 0, Invert = 1<<0, NoAction = 1<<1 };
  int box, flags = None;

  void setup(const Setting<bool> &) const;
  void setLabel(HWND, const TCHAR *) const;
  void setValue(HWND, bool) const;
  void apply(HWND, bool *)  const;
  bool hitTest(HWND, POINT) const;
  std::optional<bool> isChangeEvent(short control, short notification) const;
};

struct Combobox {
  int box, label;

  void setup(const Setting<const RendererType *> &) const {};
  void setLabel(HWND, const TCHAR *)        const;
  void setValue(HWND, const RendererType *) const;
  void apply(HWND, const RendererType **)   const;
  bool hitTest(HWND, POINT) const;
  std::optional<bool> isChangeEvent(short control, short notification) const;
};

struct RateCombobox {
  int box, label;

  void setup(const Setting<int> &) const {};
  void setLabel(HWND, const TCHAR *) const;
  void setValue(HWND, int)           const;
  void apply(HWND, int *)            const;
  bool hitTest(HWND, POINT) const;
  std::optional<bool> isChangeEvent(short control, short notification) const;
};

template<typename T> struct Control;
template<> struct Control<bool>                 { using type = Checkbox; };
template<> struct Control<const RendererType *> { using type = Combobox; };
template<> struct Control<int>                  { using type = RateCombobox; };

template<typename T>
struct Setting {
  T *value;
  T defaultValue;
  const TCHAR *key;
  const char *label, *help;
  typename Control<T>::type control;

  void read(const TCHAR *file)  const;
  void write(const TCHAR *file) const;
  void reset() const { *value = defaultValue; }
};

template<typename... Ts>
struct SettingVariant : std::variant<Setting<Ts>...> {
  template<typename T, typename... Args>
  constexpr SettingVariant(T *value, Args&&... args)
    : std::variant<Setting<Ts>...> {Setting<T> {value, args...}} {}
};

#if defined(_WIN32)
#  define PLATFORM_SUFFIX L"_win32"
#elif defined(__APPLE__)
#  define PLATFORM_SUFFIX "_cocoa"
#else
#  define PLATFORM_SUFFIX "_gdk"
#  define GDK_WORKAROUNDS
#endif

constexpr SettingVariant<bool, const RendererType *, int> SETTINGS[] {
  {&Settings::NoSavedSettings, false, TEXT("nosavedsettings"),
    "Restore window position, size, dock state and table settings",
    "Disable to force ReaImGui scripts to start with "
    "their default first-use state (safe mode).",
    Checkbox {IDC_SAVEDSETTINGS, Checkbox::Invert},
  },
  {&Settings::DockingEnable, true, TEXT("dockingenable"),
    "Enable docking by default",
    "Drag the titlebar to dock windows into REAPER dockers or into other "
    "windows of the same script instance.",
    Checkbox {IDC_DOCKINGENABLE},
  },
  {&Settings::DockingNoSplit, false, TEXT("dockingnosplit"),
    "Enable window splitting when docking",
    "Disable to limit docking to merging multiple windows together into "
    "tab bars (simplified docking mode).",
    Checkbox {IDC_DOCKSPLIT, Checkbox::Invert},
  },
  {&Settings::DockingWithShift, false, TEXT("dockingwithshift"),
    "Dock only when holding Shift",
    "Press the Shift key to disable or enable docking when dragging "
    "windows using the title bar. This option inverts the behavior.",
    Checkbox {IDC_DOCKWITHSHIFT},
  },
  {&Settings::DockingTransparentPayload, false, TEXT("dockingtransparentpayload"),
    "Make windows transparent when docking",
    "Windows become semi-transparent when docking into another window. "
    "Docking boxes are shown only in the target window.",
    Checkbox {IDC_DOCKTRANSPARENT},
  },
  {&Settings::NavEnable, true, TEXT("navenable"),
    "Enable keyboard navigation by default",
    "Navigate using the arrow keys. Space/Return/Escape to activate/"
    "deactivate widgets or close popups. Alt to jump to the menu bar.",
    Checkbox {IDC_NAVENABLE},
  },
  {&Settings::NavCaptureKbd, false, TEXT("navcapturekbd"),
    "Always capture keyboard shortcuts from the global scope",
    "Receive all keyboard input even for action shortcuts from the global scope.",
    Checkbox {IDC_NAVCAPTUREKBD},
  },
  {&Settings::NavCurAlways, false, TEXT("navcuralways"),
    "Always show the navigation cursor",
    "By default the navigation cursor is shown only when using navigation "
    "and hidden when clicking using the mouse.",
    Checkbox {IDC_NAVCURALWAYS},
  },
  {&Settings::NavMoveMouse, false, TEXT("navmovemouse"),
    "Teleport the mouse cursor when navigating",
    "Move the mouse cursor when navigating to a different widget "
    "using Tab or the arrow keys.",
    Checkbox {IDC_NAVMOVEMOUSE},
  },
  {&Settings::Renderer, nullptr, TEXT("renderer") PLATFORM_SUFFIX,
    "Graphics renderer (advanced):",
    "Select a different renderer if you encounter compatibility problems.",
    Combobox {IDC_RENDERER, IDC_RENDERERTXT},
  },
  {&Settings::ForceSoftware, false, TEXT("forcecpu") PLATFORM_SUFFIX,
#ifdef GDK_WORKAROUNDS
    "Disable hardware blitting",
    "Enable this option force the use of software blitting. May improve "
    "compatibility at the cost of potentially higher CPU usage.",
#else
    "Disable hardware acceleration",
    "Enable this option force the use of software rendering. May improve "
    "compatibility at the cost of potentially higher CPU usage.",
#endif
   Checkbox {IDC_FORCESOFTWARE, Checkbox::NoAction}
  },
  {&Settings::TimerRate, 0, TEXT("timerrate") PLATFORM_SUFFIX,
    "Script frame rate:",
    "How often REAPER runs scripts and extension timers. A faster rate applies "
    "to all of REAPER, not only nvk_GUI windows, and uses more CPU.",
    RateCombobox {IDC_TIMERRATE, IDC_TIMERRATETXT},
  },
};

constexpr const TCHAR *SECTION {TEXT("nvkgui")};

template<>
void Setting<bool>::read(const TCHAR *file) const
{
  *value = GetPrivateProfileInt(SECTION, key, defaultValue, file);
}

template<>
void Setting<const RendererType *>::read(const TCHAR *file) const
{
  TCHAR id[32];
  GetPrivateProfileString(SECTION, key, TEXT(""), id, std::size(id), file);
  *value = RendererType::bestMatch(NARROW(id));
}

template<>
void Setting<int>::read(const TCHAR *file) const
{
  *value = GetPrivateProfileInt(SECTION, key, defaultValue, file);
  if(!TimerRate::isChoice(*value)) // a rate offered on another platform
    *value = defaultValue;
}

template<>
void Setting<bool>::write(const TCHAR *file) const
{
  constexpr const TCHAR *bools[] {TEXT("0"), TEXT("1")};
  WritePrivateProfileString(SECTION, key, bools[*value], file);
}

template<>
void Setting<const RendererType *>::write(const TCHAR *file) const
{
  WritePrivateProfileString(SECTION, key, WIDEN((*value)->id), file);
}

template<>
void Setting<const RendererType *>::reset() const
{
  *value = RendererType::bestMatch("");
}

template<>
void Setting<int>::write(const TCHAR *file) const
{
  WritePrivateProfileString(SECTION, key, WIDEN(std::to_string(*value).c_str()), file);
}

void Checkbox::setLabel(HWND window, const TCHAR *text) const
{
  SetDlgItemText(window, box, text);
}

void Combobox::setLabel(HWND window, const TCHAR *text) const
{
  SetDlgItemText(window, label, text);
}

void Checkbox::setValue(HWND window, const bool value) const
{
  const bool invert {(flags & Invert) != 0};
  CheckDlgButton(window, box, value ^ invert);
}

void Combobox::setValue(HWND window, const RendererType *value) const
{
  HWND combo {GetDlgItem(window, box)};
  SendMessage(combo, CB_RESETCONTENT, 0, 0);
  for(const RendererType *type {RendererType::head()}; type; type = type->next) {
    const auto index {
      SendMessage(combo, CB_ADDSTRING, 0,
                  reinterpret_cast<LPARAM>(WIDEN(type->displayName)))
    };
    SendMessage(combo, CB_SETITEMDATA, index, reinterpret_cast<LPARAM>(type));
    if(type == value)
      SendMessage(combo, CB_SETCURSEL, index, 0);
  }
}

void RateCombobox::setLabel(HWND window, const TCHAR *text) const
{
  SetDlgItemText(window, label, text);
}

void RateCombobox::setValue(HWND window, const int value) const
{
  HWND combo {GetDlgItem(window, box)};
  SendMessage(combo, CB_RESETCONTENT, 0, 0);

  const auto add {[combo, value](const char *name, const int hz) {
    const auto index {
      SendMessage(combo, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(WIDEN(name)))
    };
    SendMessage(combo, CB_SETITEMDATA, index, hz);
    if(hz == value)
      SendMessage(combo, CB_SETCURSEL, index, 0);
  }};

  add(L10N("REAPER default"), 0);
  for(const int hz : TimerRate::choices())
    add((std::to_string(hz) + " Hz").c_str(), hz);
}

void Checkbox::apply(HWND window, bool *value) const
{
  const bool invert {(flags & Invert) != 0};
  *value = !!IsDlgButtonChecked(window, box) ^ invert;
}

void Combobox::apply(HWND window, const RendererType **value) const
{
  HWND combo {GetDlgItem(window, box)};
  const auto index {SendMessage(combo, CB_GETCURSEL, 0, 0)};
  *value = reinterpret_cast<const RendererType *>
    (SendMessage(combo, CB_GETITEMDATA, index, 0));
}

void RateCombobox::apply(HWND window, int *value) const
{
  HWND combo {GetDlgItem(window, box)};
  const auto index {SendMessage(combo, CB_GETCURSEL, 0, 0)};
  *value = static_cast<int>(SendMessage(combo, CB_GETITEMDATA, index, 0));
}

static bool hitTest(HWND window, const POINT point, const int control)
{
  RECT rect;
  GetWindowRect(GetDlgItem(window, control), &rect);
  return PtInRect(&rect, point);
}

bool Checkbox::hitTest(HWND window, const POINT point) const
{
  return ::hitTest(window, point, box);
}

bool Combobox::hitTest(HWND window, const POINT point) const
{
  return ::hitTest(window, point, box) || ::hitTest(window, point, label);
}

bool RateCombobox::hitTest(HWND window, const POINT point) const
{
  return ::hitTest(window, point, box) || ::hitTest(window, point, label) ||
    ::hitTest(window, point, IDC_TIMERRATESTATUS);
}

std::optional<bool> Checkbox::isChangeEvent
  (const short controlId, const short notification) const
{
  if(controlId == box)
    return notification == BN_CLICKED;
  return std::nullopt;
}

std::optional<bool> Combobox::isChangeEvent
  (const short controlId, const short notification) const
{
  if(controlId == box)
    return notification == CBN_SELCHANGE;
  return std::nullopt;
}

std::optional<bool> RateCombobox::isChangeEvent
  (const short controlId, const short notification) const
{
  if(controlId == box)
    return notification == CBN_SELCHANGE;
  return std::nullopt;
}

static std::string makeActionName(const TCHAR *key)
{
  std::string name {narrow(key)};
  std::transform(name.begin(), name.end(), name.begin(), toupper);
  return name;
}

void Checkbox::setup(const Setting<bool> &setting) const
{
  if(flags & NoAction)
    return;

  const bool invert {(flags & Invert) != 0};
  new Action {
    makeActionName(setting.key), setting.label,
    [value = setting.value        ] { *value = !*value;       },
    [value = setting.value, invert] { return *value ^ invert; },
  };
}

static void updateHelp(HWND hwnd)
{
  constexpr int IDC_PREFS_HELP {0x4eb}, IDT_PREFS_HELP_CLEAR {0x654};

  static const char *shownText;

  if(!IsWindowVisible(hwnd)) {
    shownText = nullptr;
    return; // another preference page is active
  }

  HWND prefs {GetParent(hwnd)};
  KillTimer(prefs, IDT_PREFS_HELP_CLEAR);

  POINT point;
  GetCursorPos(&point);

  for(const auto &setting : SETTINGS) {
    if(std::visit([hwnd, point](const auto &setting) {
      if(!setting.control.hitTest(hwnd, point))
        return false;
      if(shownText == setting.help)
        return true; // repeatedly setting the same text flickers on Windows
      shownText = setting.help;
      SetDlgItemText(GetParent(hwnd), IDC_PREFS_HELP, WIDEN(L10N(setting.help)));
      return true;
    }, setting))
      return;
  }

  shownText = nullptr;
  SetTimer(prefs, IDT_PREFS_HELP_CLEAR, 200, nullptr); // same speed as REAPER
}

static bool isChangeEvent(const short control, const short notification)
{
  for(const auto &setting : SETTINGS) {
    if(auto rv {std::visit([control, notification] (const auto &setting) {
      return setting.control.isChangeEvent(control, notification);
    }, setting)})
      return *rv;
  }

  return false;
}

template<typename T>
static const Setting<T> *findSetting(T *value)
{
  for(const auto &variant : SETTINGS) {
    const auto setting {std::get_if<Setting<T>>(&variant)};
    if(setting && setting->value == value)
      return setting;
  }

  return nullptr;
}

static void updateRendererOptions(HWND hwnd)
{
  static auto renderer      {findSetting(&Settings::Renderer)};
  static auto forceSoftware {findSetting(&Settings::ForceSoftware)};

  const RendererType *type;
  renderer->control.apply(hwnd, &type);

  EnableWindow(GetDlgItem(hwnd, forceSoftware->control.box),
    type->flags & RendererType::CanForceSoftware);
}

constexpr UINT_PTR IDT_TIMERRATE_STATUS {0x6e0};

static void updateTimerRateStatus(HWND hwnd)
{
  std::string status;
  if(const int ms {TimerRate::baselineIntervalMs()}) {
    status = L10N("Default here: ");
    status += std::to_string(static_cast<int>(std::lround(1000.0 / ms)));
    status += L10N(" Hz");
    if(TimerRate::foreignOverrideLoaded())
      status += L10N(" (set by reaper_60fps)");
    KillTimer(hwnd, IDT_TIMERRATE_STATUS);
  }
  else {
    status = L10N("Measuring default...");
    // the baseline is measured about a second after REAPER starts
    SetTimer(hwnd, IDT_TIMERRATE_STATUS, 250, nullptr);
  }

  SetDlgItemText(hwnd, IDC_TIMERRATESTATUS, WIDEN(status.c_str()));
}

// Faster rates affect all of REAPER: confirm before leaving the default.
static void confirmTimerRate(HWND hwnd)
{
  static auto timerRate {findSetting(&Settings::TimerRate)};

  int rate;
  timerRate->control.apply(hwnd, &rate);
  if(!rate || Settings::TimerRate)
    return;

  if(IDOK == MessageBox(hwnd,
      WIDEN(L10N("A faster script frame rate makes REAPER run every script and "
                 "extension timer more often, not only nvk_GUI windows, and "
                 "increases CPU use. Other scripts that assume REAPER's default "
                 "rate may behave differently.\n\nUse the faster rate?")),
      WIDEN(L10N("nvk_GUI settings")),
      MB_OKCANCEL | MB_ICONWARNING))
    return;

  timerRate->control.setValue(hwnd, Settings::TimerRate);
}

static void resetDefaults(HWND hwnd)
{
  if(IDOK != MessageBox(hwnd,
      WIDEN(L10N("Are you sure you want to restore the default settings?")),
      WIDEN(L10N("nvk_GUI settings")),
      MB_OKCANCEL | MB_ICONWARNING))
    return;

  for(const auto &setting : SETTINGS) {
    std::visit([hwnd] (const auto &setting) {
      setting.reset();
      setting.control.setValue(hwnd, *setting.value);
    }, setting);
  }

  Settings::save();
  Action::refreshAll();
  TimerRate::apply();
  updateRendererOptions(hwnd);
}

static void processCommand(HWND hwnd,
  const short control, const short notification)
{
  if(isChangeEvent(control, notification)) {
    constexpr int IDC_PREFS_APPLY {0x478};
    EnableWindow(GetDlgItem(GetParent(hwnd), IDC_PREFS_APPLY), true);
    if(control == IDC_RENDERER)
      updateRendererOptions(hwnd);
    else if(control == IDC_TIMERRATE)
      confirmTimerRate(hwnd);
    return;
  }

  switch(control) {
  case IDC_RESETDEFAULTS:
    resetDefaults(hwnd);
    break;
  }
}

static WDL_DLGRET settingsProc(HWND hwnd, const unsigned int message,
  const WPARAM wParam, const LPARAM)
{
  constexpr int WM_PREFS_APPLY {WM_USER * 2};
  static WDL_WndSizer resizer;

  switch(message) {
  case WM_INITDIALOG: {
    for(const auto &setting : SETTINGS) {
      std::visit([hwnd] (const auto &setting) {
        setting.control.setLabel(hwnd, WIDEN(L10N(setting.label)));
        setting.control.setValue(hwnd, *setting.value);
      }, setting);
    }
    updateRendererOptions(hwnd);
    updateTimerRateStatus(hwnd);
    EnableWindow(GetDlgItem(hwnd, IDC_VERSION), false);
    resizer.init(hwnd);
    resizer.init_item(IDC_GROUPBOX, 0.f, 0.f, 1.f, 1.f);
    resizer.init_item(IDC_VERSION, 0.f, 1.f, 0.f, 1.f);
    resizer.init_item(IDC_RESETDEFAULTS, 1.f, 1.f, 1.f, 1.f);
    return 0; // don't focus the first control
  }
  case WM_SIZE:
    resizer.onResize();
    return 0;
  case WM_TIMER:
    if(wParam == IDT_TIMERRATE_STATUS)
      updateTimerRateStatus(hwnd);
    return 0;
  case WM_SHOWWINDOW: // to clear shownText when the page becomes inactive
    if(wParam)
      updateTimerRateStatus(hwnd); // the baseline may have been measured since
    [[fallthrough]];
  case WM_SETCURSOR:  // WM_MOUSEMOVE is not sent over children controls (win32)
    updateHelp(hwnd);
    return 0;
  case WM_COMMAND:
    processCommand(hwnd, LOWORD(wParam), HIWORD(wParam));
    return 0;
  case WM_PREFS_APPLY:
    for(const auto &setting : SETTINGS) {
      std::visit([hwnd] (const auto &setting) {
        setting.control.apply(hwnd, setting.value);
      }, setting);
    }
    Settings::save();
    Action::refreshAll();
    TimerRate::apply();
    updateTimerRateStatus(hwnd);
    return 0;
  }

  return 0;
}

static HWND create(HWND parent)
{
  return CreateDialogL(
    Window::s_instance, MAKEINTRESOURCE(IDD_SETTINGS), parent, &settingsProc);
}

static prefs_page_register_t g_page {
  "nvkgui", "nvk_GUI", &create,
  0x9a, "", // parent page ID (Plug-ins, unknown parent idstr)
  0,        // won't have children
};

void Settings::open()
{
  ViewPrefs(0, g_page.idstr);
}

void Settings::setup()
{
  plugin_register("prefpage", reinterpret_cast<void *>(&g_page));

#ifdef _WIN32
  const std::wstring &fn {widen(get_ini_file())};
  const wchar_t *file {fn.c_str()};
#else
  const char *file {get_ini_file()};
#endif

#ifdef __APPLE__
  // Developer-only: do not expose or write this flag through normal preferences.
  // Read the INI directly (not ExtState), so it is available at extension load.
  char automationInput[3] {};
  GetPrivateProfileString(SECTION, "dev_automation_input", "",
    automationInput, sizeof(automationInput), file);
  DevAutomationInput = automationInput[0] == '1' && automationInput[1] == '\0';
#endif

  for(const auto &setting : SETTINGS) {
    std::visit([file] (const auto &setting) {
      setting.read(file);
      setting.control.setup(setting);

      // store default settings without waiting for the user to apply
      setting.write(file);
    }, setting);
  }

  TimerRate::setup(); // measures REAPER's rate, then applies TimerRate
}

void Settings::save()
{
#ifdef _WIN32
  const std::wstring &fn {widen(get_ini_file())};
  const wchar_t *file {fn.c_str()};
#else
  const char *file {get_ini_file()};
#endif

  for(const auto &setting : SETTINGS)
    std::visit([file] (const auto &setting) { setting.write(file); }, setting);
}

void Settings::teardown()
{
  TimerRate::teardown();
  plugin_register("-prefpage", reinterpret_cast<void *>(&g_page));
}
