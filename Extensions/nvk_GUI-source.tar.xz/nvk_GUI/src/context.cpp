/* ReaImGui: ReaScript binding for Dear ImGui
 * Copyright (C) 2021-2025  Christian Fillion
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "context.hpp"

#include "color.hpp"
#include "configvar.hpp"
#include "docker.hpp"
#include "error.hpp"
#include "font.hpp"
#include "font_registry.hpp"
#include "image.hpp"
#include "display_clock.hpp"
#include "native_region.hpp"
#include "keymap.hpp"
#include "platform.hpp"
#include "renderer.hpp"
#include "settings.hpp"
#include "viewport.hpp"
#include "window.hpp"

#include <cassert>
#include <imgui/imgui_internal.h>
#include <reaper_plugin_functions.h>
#include <WDL/wdltypes.h>
#include <zlib/zlib.h>

#ifdef _WIN32
#  include "win32_unicode.hpp"
#endif

enum StateFlags {
  DnD_Cancelled = 1<<0,
  DnD_WasActive = 1<<1,

#ifdef __APPLE__
  // Right Click Emulation
  RCE_Armed  = 1<<2,
  RCE_Active = 1<<3,
#endif
};

constexpr ImGuiMouseButton DND_MouseButton {ImGuiMouseButton_Left};
constexpr ImGuiConfigFlags PRIVATE_CONFIG_FLAGS
  {ImGuiConfigFlags_ViewportsEnable};

// nvk_GUI: TestInput's busy and idle timing.
static double testInputClock()
{
  using Clock = std::chrono::steady_clock;
  return std::chrono::duration<double> {Clock::now().time_since_epoch()}.count();
}

class TempCurrent {
public:
  TempCurrent(Context *ctx)
    : m_old {ImGui::GetCurrentContext()} { ctx->setCurrent(); }
  ~TempCurrent() { ImGui::SetCurrentContext(m_old); }

private:
  ImGuiContext *m_old;
};

struct Subresource {
  Subresource(Context *c, Resource *r)
    : data {r->install(c)}, resource {r}, uniqId {r->uniqId()}, unusedFrames {}
  {}

  bool isResourceValid() const {
    return Resource::isValid(resource) && uniqId == resource->uniqId(); }
  bool operator==(Resource *other) const {
    return resource == other && uniqId == other->uniqId(); }
  bool operator==(void *other) const { return data == other; }

  SubresourceData data;
  Resource *resource;
  unsigned int uniqId; // resource->uniqId() to detect pointer reuse
  unsigned char unusedFrames;
};

static std::string generateIniFilename(const ImGuiID id)
{
  std::string filename {GetResourcePath()};

  filename += WDL_DIRCHAR_STR "nvk_GUI";
  RecursiveCreateDirectory(filename.c_str(), 0);

  const size_t pathSize {filename.size()}, idSize {sizeof(id) * 2};
  filename.resize(pathSize + idSize + strlen(WDL_DIRCHAR_STR ".ini"));
  snprintf(&filename[pathSize], (filename.size() - pathSize) + 1,
    WDL_DIRCHAR_STR "%0*X.ini", static_cast<int>(idSize), id);

  return filename;
}

Context *Context::current()
{
  if(ImGuiContext *imgui {ImGui::GetCurrentContext()})
    return static_cast<Context *>(imgui->IO.UserData);
  else
    return nullptr;
}

void Context::clearCurrent()
{
  ImGui::SetCurrentContext(nullptr);
}

Context::Context(const char *label, const int userConfigFlags)
  : m_id {ImHashStr(label)},
#ifdef __APPLE__
    m_eventMouse {Settings::DevAutomationInput},
#endif
    m_stateFlags {}, m_cursor {}, m_frameCallback {},
    m_lastFrame       {decltype(m_lastFrame)::clock::now()               },
    m_name            {label, ImGui::FindRenderedTextEnd(label)          },
    m_iniFilename     {generateIniFilename(m_id)                         },
    m_imgui           {ImGui::CreateContext(FontRegistry::atlasForNewContext())},
    m_dockers         {std::make_unique<DockerList>()                    },
    m_rendererFactory {std::make_unique<RendererFactory>()               },
    m_font            {new SysFont {SysFont::SANS_SERIF}                 },
    m_regions         {std::make_unique<NativeRegion::Compositor>()      }
{
  if(!*label) // does not prohibit empty window titles
    throw reascript_error {"context label is required"};

  static const std::string logFn
    {std::string {GetResourcePath()} + WDL_DIRCHAR_STR "nvkgui_log.txt"};

  setCurrent();

  ImGuiIO &io {m_imgui->IO};
  io.BackendRendererName = m_rendererFactory->name();
  io.BackendFlags |= ImGuiBackendFlags_HasMouseCursors;
  io.BackendFlags |= ImGuiBackendFlags_HasMouseHoveredViewport;
  io.BackendFlags |= ImGuiBackendFlags_HasSetMousePos;
  io.BackendFlags |= ImGuiBackendFlags_PlatformHasViewports;
  io.BackendFlags |= ImGuiBackendFlags_RendererHasTextures;
  io.BackendFlags |= ImGuiBackendFlags_RendererHasViewports;
  io.BackendFlags |= ImGuiBackendFlags_RendererHasVtxOffset;
  io.ConfigDebugIsDebuggerPresent = true;
  // Existing ReaScript primitives use the pre-1.93 stroke coordinates. Keep
  // their placement while using the new renderer and its optimized paths.
  io.ConfigDebugDrawListDefaultsToStrokeLegacy = true;
  io.ConfigDockingNoSplit = Settings::DockingNoSplit;
  io.ConfigDockingTransparentPayload = Settings::DockingTransparentPayload;
  io.ConfigDockingWithShift = Settings::DockingWithShift;
  io.ConfigNavCaptureKeyboard = Settings::NavCaptureKbd;
  io.ConfigNavCursorVisibleAlways = Settings::NavCurAlways;
  io.ConfigNavMoveSetMousePos = Settings::NavMoveMouse;
  io.Fonts->Flags |= ImFontAtlasFlags_NoMouseCursors;
  io.LogFilename = logFn.c_str();
  io.UserData = this;

  m_imgui->ErrorCallback = [](ImGuiContext *ctx, void *, const char *msg) {
    // report clean error messages without assertion decorations ('0 && "msg"')
    if(ctx->IO.ConfigErrorRecoveryEnableAssert)
      throw imgui_error {msg};
    // nvk_GUI: recovery is on, so ImGui unwinds the stack itself and the
    // script reads what happened with TakeRecoveredError.
    static_cast<Context *>(ctx->IO.UserData)->recordRecoveredError(msg);
  };
  io.ConfigErrorRecoveryEnableAssert = true;
  io.ConfigErrorRecoveryEnableTooltip = false;
  io.ConfigErrorRecoveryEnableDebugLog = false;

  setUserConfigFlags(userConfigFlags);
  if(Settings::DockingEnable)
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
  if(Settings::NavEnable)
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

  Platform::install();
  Renderer::install();
  Viewport::install();

  ImGuiStyle &style {m_imgui->Style};
  style.FontSizeBase = 12.f; // 9pt
  style.FramePadding.y = 2.f;
  if(!usesSharedAtlas()) // the registry configured the shared atlas already
    io.Fonts->SetFontLoader(Font::loader());
  io.FontDefault = m_font->instance(this);
  FontRegistry::ensureFrameInit(); // needs >= 1 font in the shared atlas

  // prevent imgui from loading settings but not from saving them
  // (so that the saved state is reset to defaults)
  if(Settings::NoSavedSettings)
    m_imgui->SettingsLoaded = true;

  screenset_registerNew(screensetKey().data(), &screensetProc, this);
}

Context::~Context()
{
  setCurrent();
  screenset_unregisterByParam(this);

  if(m_imgui->WithinFrameScope)
    endFrame(false);

  // destroy windows while this and m_imgui are still valid
  ImGui::DestroyPlatformWindows();
  // ...and run usage data destructors
  for(Subresource &sr : m_subresources)
    sr.data.uninstall(this);

  // GPU-release this context's textures: a ProcessShared block outlives the
  // last window, so its destructor no longer sweeps them on our behalf.
  // The registry's shared atlas is deliberately left alone -- its baked
  // textures persist for other contexts and future script (re)opens.
  if(!usesSharedAtlas()) {
    for(ImTextureData *tex : m_imgui->IO.Fonts->TexList) {
      if(tex->GetTexID() != ImTextureID_Invalid)
        m_rendererFactory->destroyTexture(tex);
    }
  }
  for(ImTextureData *tex : m_imgui->UserTextures) {
    if(tex->GetTexID() != ImTextureID_Invalid)
      m_rendererFactory->destroyTexture(tex);
  }

  for(ImTextureData *tex : m_imgui->UserTextures) {
    IM_ASSERT(tex->TexID == ImTextureID_Invalid); // renderer did clean up
    tex->Pixels = nullptr;
    delete tex;
  }
}

void Context::ContextDeleter::operator()(ImGuiContext *imgui)
{
  ImGui::DestroyContext(imgui);
}

int Context::userConfigFlags() const
{
  return m_imgui->IO.ConfigFlags & ~PRIVATE_CONFIG_FLAGS;
}

void Context::setUserConfigFlags(const int userFlags)
{
  m_imgui->IO.ConfigFlags = userFlags | PRIVATE_CONFIG_FLAGS;
}

void Context::attach(Resource *obj)
{
  // Sorted set: isAttached runs once per subresource per frame, and an image
  // cache attaches thousands of objects.
  if(m_attachments.size() >= 0x2000)
    throw reascript_error {"exceeded maximum object attachment limit"};
  if(m_attachments.contains(obj))
    throw reascript_error {"the object is already attached to this context"};
  else if(!obj->attachable(this))
    throw reascript_error {"the object cannot be attached to this context"};

  m_attachments.insert(obj);
}

void Context::detach(Resource *obj)
{
  if(!m_attachments.contains(obj))
    throw reascript_error {"the object is not attached to this context"};

  m_attachments.erase(obj);
}

bool Context::isAttached(Resource *obj) const
{
  return m_attachments.contains(obj);
}

bool Context::usesSharedAtlas() const
{
  return FontRegistry::isSharedAtlas(m_imgui->IO.Fonts);
}

void Context::present()
{
  // Renders and presents right away instead of at the end of the defer
  // cycle. A new script window normally becomes visible only after two
  // timer ticks (frame one computes auto-fit sizing, frame two shows);
  // presenting from within the script's own defer callback removes that
  // wait. Anything drawn after this call starts a new frame.
  if(m_imgui->WithinFrameScope)
    endFrame(true);
}

void Context::replay() try
{
  // Stale frames must not move on under a frozen script: skip while REAPER's
  // timer is held up (menus, modal dialogs, live resize) or a frame is open.
  constexpr double MAX_TIMER_SILENCE {0.1};
  if(!m_liveRegions || m_imgui->WithinFrameScope ||
      Resource::secondsSinceTick() > MAX_TIMER_SILENCE)
    return;

  TempCurrent current {this};
  ImGuiPlatformIO &pio {ImGui::GetPlatformIO()};

  // A replayed frame may only bind textures that are still alive: the shared
  // atlas or an image freed since the frame was built would dangle.
  for(const ImTextureData *tex : pio.Textures) {
    if(tex->Status != ImTextureStatus_OK || tex->WantDestroyNextFrame)
      return;
  }

  m_regions->composite();
  for(int i {1}; i < pio.Viewports.Size; ++i) { // 0 is REAPER's main window
    ImGuiViewport *viewport {pio.Viewports[i]};
    const ImDrawData *drawData {viewport->DrawData};
    if((viewport->Flags & ImGuiViewportFlags_IsMinimized) ||
        !viewport->PlatformUserData || !drawData || !drawData->Valid)
      continue;

    // A frame still waiting for the display is what the screen shows next;
    // presenting another would block until it is out, stalling REAPER.
    const Viewport *instance {static_cast<Viewport *>(viewport->PlatformUserData)};
    if(!instance->canPresentNow())
      continue;

    // resized since: the frame no longer fits the drawable
    const ImVec2 size {instance->getSize()};
    if(size.x != drawData->DisplaySize.x || size.y != drawData->DisplaySize.y)
      continue;

    if(pio.Renderer_RenderWindow)
      pio.Renderer_RenderWindow(viewport, nullptr);
    if(pio.Renderer_SwapBuffers)
      pio.Renderer_SwapBuffers(viewport, nullptr);
  }
  m_liveRegions = m_regions->live();
}
catch(const backend_error &e) {
  m_liveRegions = false;
  Error::report(this, e);
}

template<>
void *Context::touch<void>(Resource *obj)
{
  auto it {std::find(m_subresources.begin(), m_subresources.end(), obj)};
  if(it == m_subresources.end()) {
    m_subresources.emplace_back(this, obj);
    it = m_subresources.end() - 1;
  }
  else
    it->unusedFrames = 0;
  return it->data;
}

bool Context::heartbeat()
{
  m_font->keepAlive();
  for(Resource *obj : m_attachments)
    obj->keepAlive();

  if(m_frameCallback)
    m_frameCallback(this);

  if(m_imgui->WithinFrameScope && !endFrame(true))
    return false;

  // Keep the frame alive for at least one full timer cycle to prevent contexts
  // created within a defer callback from being immediately destroyed.
  return Resource::heartbeat();
}

ImGuiIO &Context::IO()
{
  return m_imgui->IO;
}

void Context::setErrorRecovery(const bool enable)
{
  m_imgui->IO.ConfigErrorRecovery = true;
  m_imgui->IO.ConfigErrorRecoveryEnableAssert = !enable;
}

void Context::recordRecoveredError(const char *message)
{
  if(m_recoveredCount++ == 0)
    m_recoveredError = message ? message : "";
}

const char *Context::takeRecoveredError()
{
  if(m_recoveredCount == 0)
    m_takenError.clear();
  else if(m_recoveredCount == 1)
    m_takenError = m_recoveredError;
  else
    m_takenError = std::format("{} (and {} more)", m_recoveredError, m_recoveredCount - 1);
  m_recoveredError.clear();
  m_recoveredCount = 0;
  return m_takenError.c_str();
}

ImGuiStyle &Context::style()
{
  return m_imgui->Style;
}

void Context::setCurrent()
{
  ImGui::SetCurrentContext(m_imgui.get());
}

bool Context::beginFrame() try
{
  touch<void>(m_font);
  assert(!m_imgui->WithinFrameScope);

  Platform::updateMonitors(); // TODO only if changed

  updateFrameInfo();
  updateMouseData();
  updateSettings();

  ImGui::NewFrame();
  // Preserve the binding's live scalar edits (upstream changed its default in
  // 1.92.9). Set the base item scope without introducing an unmatched push.
  m_imgui->ItemFlagsStack[0] |= ImGuiItemFlags_LiveEditOnInputScalar;
  m_imgui->CurrentItemFlags = m_imgui->ItemFlagsStack[0];
  applyTestFocus();

  dragSources();
  m_dockers->drawAll();

  return true;
}
catch(const backend_error &e) {
  Error::report(this, e);
  return false;
}

bool Context::enterFrame()
{
  setCurrent();

  if(m_imgui->WithinFrameScope)
    return true;
  else
    return beginFrame();
}

bool Context::endFrame(const bool render) try
{
  setCurrent();

  if(!render) {
    ImGui::EndFrame();
    return true;
  }

  updateCursor();
  updateDragDrop();
  updateSubresources();
  ImGui::Render();
  Bitmap::holdTexturesWithoutPixels(m_imgui->PlatformIO.Textures);
  ImGui::UpdatePlatformWindows();
  m_regions->composite(); // paints native regions into copies of the draw lists
  ImGui::RenderPlatformWindowsDefault();
  m_liveRegions = m_regions->live();
  if(m_liveRegions)
    DisplayClock::request();
  cleanupTextures();

#ifdef FOCUS_POLLING
  // WM_KILLFOCUS/WM_ACTIVATE+WA_INACTIVE are incomplete or missing in SWELL
  updateFocus();
#endif

  return true;
}
catch(const imgui_error &e) {
  if(render) { // silence further errors on the way out (during destruction)
    ImGuiWindow *window {m_imgui->CurrentWindow};
    const char *name {window ? window->Name : "NULL"};
    Error::report(this, imgui_error {"In window \"{}\": {}", name, e.what()});
  }
  // don't retry EndFrame and error out again during destruction
  m_imgui->WithinFrameScope = false;
  return false;
}
catch(const backend_error &e) {
  Error::report(this, e);
  return false;
}

void Context::updateFrameInfo()
{
  ImGuiIO &io {m_imgui->IO};

  // Dear ImGui doesn't call MainViewport::getSize
  ImGuiViewport *mainViewport {ImGui::GetMainViewport()};
  Viewport *mainViewportInstance
    {static_cast<Viewport *>(mainViewport->PlatformUserData)};
  mainViewport->Pos = mainViewportInstance->getPosition();
  io.DisplaySize = mainViewport->Size = mainViewportInstance->getSize();

  const auto now {decltype(m_lastFrame)::clock::now()};
  io.DeltaTime = std::chrono::duration<float> {now - m_lastFrame}.count();
  m_lastFrame = now;

  // Workaround to prevent stuck keys when keyboard capture is released in
  // reaction to pressing down an action's global shortcut key
  // (REAPER won't send the key up event to us)
  if(io.WantCaptureKeyboard && isAnyKeyDown())
    ImGui::SetNextFrameWantCaptureKeyboard(true);
}

void Context::updateCursor()
{
  if(m_imgui->IO.ConfigFlags & ImGuiConfigFlags_NoMouseCursorChange)
    return;

  // ImGui::GetMouseCursor is only valid after a frame, before Render
  // (it's reset when a new frame is started)
  HCURSOR nativeCursor {Platform::getCursor(ImGui::GetMouseCursor())};
  if(m_cursor != nativeCursor)
    SetCursor(m_cursor = nativeCursor);
}

void Context::updateMouseData()
{
  ImGuiIO &io {m_imgui->IO};

  // Injected input never warps the person's cursor, which it no longer reads.
  if(io.WantSetMousePos && m_testInput.owns())
    return;
  if(io.WantSetMousePos) {
    ImVec2 scaledPos {io.MousePos};
    Platform::scalePosition(&scaledPos, true);
    SetCursorPos(scaledPos.x, scaledPos.y);
    return;
  }

  ImVec2 pos {Platform::getCursorPos()};
  if(m_testInput.owns()) {
    if(!m_testInput.acceptRealCursor(m_imgui.get(), pos,
        viewportUnder(pos) != nullptr, testInputClock()))
      return;
    updateFocus(); // the person took the context back
  }
#ifdef __APPLE__
  if(m_draggedFiles.empty() && !(m_stateFlags & DnD_Cancelled) &&
      !m_eventMouse.shouldPoll(m_imgui.get(), pos))
    return;
#endif

  ImGuiID hoveredViewport {0};
  ImGuiViewport *viewportForPos {nullptr};
  HWND capture {m_draggedFiles.empty() ? Platform::getCapture() : nullptr};
  if(ImGuiViewport *viewportForInput {viewportUnder(pos)}) {
    if(!capture || Window::contextFromHwnd(capture) == this) {
      viewportForPos = viewportForInput;
      hoveredViewport = viewportForInput->ID;
    }
  }
  else if(capture)
    viewportForPos = ImGui::FindViewportByPlatformHandle(capture);

  io.AddMouseViewportEvent(hoveredViewport);

  if(viewportForPos && ImGui::GetMainViewport() != viewportForPos &&
      !(m_stateFlags & DnD_Cancelled))
    Platform::scalePosition(&pos, false, viewportForPos);
  else
    pos.x = pos.y = -FLT_MAX;

  io.AddMousePosEvent(pos.x, pos.y);
}

#ifdef __APPLE__
void Context::mousePosition(ImGuiViewport *viewport, ImVec2 nativePosition)
{
  if(!m_eventMouse.enabled() || !m_draggedFiles.empty() ||
      m_stateFlags & DnD_Cancelled || m_testInput.owns())
    return;

  const ImVec2 cursor {Platform::getCursorPos()};
  Platform::scalePosition(&nativePosition, false, viewport);
  const ImRect bounds {viewport->Pos,
    {viewport->Pos.x + viewport->Size.x, viewport->Pos.y + viewport->Size.y}};
  m_eventMouse.position(m_imgui.get(),
    bounds.Contains(nativePosition) ? viewport->ID : 0, nativePosition, cursor);
}
#endif

void Context::mouseInput(int button, const bool down)
{
  if(!m_testInput.acceptRealEvent(m_imgui.get(), down, testInputClock()))
    return;

#ifdef __APPLE__
  if(button == ImGuiMouseButton_Left &&
      m_stateFlags & (down ? RCE_Armed : RCE_Active)) {
    button = ImGuiMouseButton_Right;
    if(down)
      m_stateFlags |= RCE_Active;
    else
      m_stateFlags &= ~RCE_Active;
  }
#endif

  // always disable imgui's right click emulation which forwards Ctrl unlike REAPER's
  // https://github.com/ocornut/imgui/pull/2343#issuecomment-2118602304
  const bool oldMacOSBehaviors {m_imgui->IO.ConfigMacOSXBehaviors};
  m_imgui->IO.ConfigMacOSXBehaviors = false;
  m_imgui->IO.AddMouseButtonEvent(button, down);
  m_imgui->IO.ConfigMacOSXBehaviors = oldMacOSBehaviors;
}

void Context::mouseWheel(const bool horizontal, float delta)
{
#ifndef WHEEL_DELTA
  constexpr float WHEEL_DELTA {
#  ifdef __APPLE__
    60.0f
#  else
    120.0f
#  endif
  };
#endif

  if(!m_testInput.acceptRealEvent(m_imgui.get(), true, testInputClock()))
    return;

  delta /= WHEEL_DELTA;

  if(horizontal)
    m_imgui->IO.AddMouseWheelEvent(delta, 0.0f);
  else
    m_imgui->IO.AddMouseWheelEvent(0.0f, delta);
}

void Context::keyInput(ImGuiKey key, const bool down)
{
  if(!m_testInput.acceptRealEvent(m_imgui.get(), down, testInputClock()))
    return;

#ifdef __APPLE__
  // Preferences > Editing Behavior > Mouse >
  // Control+left-click emulates right-click
  static ConfigVar<int> rightclickemulate {"rightclickemulate"};
  if(rightclickemulate.value_or(false)) {
    switch(key) {
    case ImGuiMod_Ctrl:
    case ImGuiKey_LeftCtrl:
    case ImGuiKey_RightCtrl:
      if(down)
        m_stateFlags |= RCE_Armed;
      else
        m_stateFlags &= ~RCE_Armed;
      return;
    default:
      break;
    }
  }
#endif

  if(ImGui::IsLegacyKey(key))
    key = KeyMap::translateVirtualKey(key);

  m_imgui->IO.AddKeyEvent(key, down);
}

void Context::charInput(const unsigned int codepoint)
{
  if(codepoint < 32 || (codepoint >= 0x7f && codepoint <= 0x9f) || // control chars
      (codepoint >= 0xf700 && codepoint <= 0xf7ff)) // unicode private range
    return;
  if(!m_testInput.acceptRealEvent(m_imgui.get(), false, testInputClock()))
    return;

  m_imgui->IO.AddInputCharacter(codepoint);
}

void Context::charInputUTF16(const ImWchar16 unit)
{
  if(!m_testInput.acceptRealEvent(m_imgui.get(), false, testInputClock()))
    return;
  m_imgui->IO.AddInputCharacterUTF16(unit);
}

void Context::updateSettings()
{
  ImGuiIO &io {m_imgui->IO};
  if(io.ConfigFlags & ReaImGuiConfigFlags_NoSavedSettings)
    io.IniFilename = nullptr;
  else
    io.IniFilename = m_iniFilename.c_str();
}

void Context::updateDragDrop()
{
  // Ensuring drag and drop was active for at least one frame is required for
  // allowing beginDrag+endDrag to be called on the same frame on systems
  // that only notify on drop (SWELL-GDK)
  const bool active_now {ImGui::IsDragDropActive()};
  if(m_stateFlags & DnD_WasActive && !active_now) {
    m_draggedFiles.clear();
    m_stateFlags &= ~(DnD_WasActive | DnD_Cancelled);
  }
  else if(active_now)
    m_stateFlags |= DnD_WasActive;
}

// While files from the operating system are over our window, the OS owns the
// mouse, so any other drag still active is one the script left behind when it
// handed its own drag to the OS (and got the files dropped back on itself).
// Dear ImGui would continue that drag and keep the flags it began with instead
// of ours: with SourceNoPreviewTooltip among them, EndDragDropSource skips the
// EndTooltip matching our BeginDragDropSource and the frame ends with
// "Missing End()". Start ours from a clean state instead.
static void releaseStaleDrag()
{
  if(!ImGui::IsDragDropActive())
    return;
  const ImGuiPayload *payload {ImGui::GetDragDropPayload()};
  if(!payload || !payload->IsDataType(REAIMGUI_PAYLOAD_TYPE_FILES))
    ImGui::ClearDragDrop();
}

void Context::dragSources()
{
  constexpr ImGuiDragDropFlags flags
    {ImGuiDragDropFlags_SourceExtern | ImGuiDragDropFlags_PayloadAutoExpire};

  if(m_draggedFiles.empty())
    return;

  // Checking &DnD_WasActive is required to support single-frame drag/drop
  // when input queue tickling is disabled
  if(m_stateFlags & DnD_WasActive &&
      !ImGui::IsMouseDown(DND_MouseButton) &&
      !ImGui::IsMouseReleased(DND_MouseButton))
    return;

  releaseStaleDrag();
  if(!ImGui::BeginDragDropSource(flags))
    return;

  ImGui::SetDragDropPayload(REAIMGUI_PAYLOAD_TYPE_FILES, nullptr, 0);
  for(const std::string &file : m_draggedFiles) {
    size_t fnPos {file.rfind(WDL_DIRCHAR_STR)};
    if(fnPos == std::string::npos)
      fnPos = 0;
    else
      ++fnPos;
    if(m_draggedFiles.size() > 1)
      ImGui::Bullet();
    ImGui::TextUnformatted(&file[fnPos]);
  }
  ImGui::EndDragDropSource();
}

void Context::beginDrag(std::vector<std::string> &&files)
{
  m_draggedFiles = std::move(files);

  m_imgui->IO.AddMousePosEvent(-FLT_MAX, -FLT_MAX);
  m_imgui->IO.AddMouseButtonEvent(DND_MouseButton, true);
}

#ifndef __APPLE__
void Context::beginDrag(HDROP drop)
{
  unsigned int count {DragQueryFile(drop, -1, nullptr, 0)};
  std::vector<std::string> files {count};
  for(unsigned int i {0}; i < count; ++i) {
    std::string &file {files[i]};
#ifdef _WIN32
    std::wstring wideFile(DragQueryFile(drop, i, nullptr, 0), L'\0');
    DragQueryFile(drop, i, wideFile.data(), wideFile.size() + 1);
    file = narrow(wideFile);
#else
    file.resize(DragQueryFile(drop, i, nullptr, 0));
    DragQueryFile(drop, i, file.data(), file.size() + 1);
#endif
  }
  beginDrag(std::move(files));
}
#endif

void Context::endDrag(const bool drop)
{
  if(!drop) {
    // Keep the mouse position invalid until m_draggedFiles is cleared
    // to prevent accidental drop (IDropSource may call endDrag(false)
    // while the mouse is still over our window, but near another app's
    // window border or title bar).
    m_stateFlags |= DnD_Cancelled;

    m_imgui->IO.AddMousePosEvent(-FLT_MAX, -FLT_MAX);
  }

  m_imgui->IO.AddMouseButtonEvent(DND_MouseButton, false);
}

void Context::updateSubresources()
{
  for(auto it = m_subresources.begin(); it != m_subresources.end();) {
    // Attached resources are pinned: without this, an attached font unused
    // for SUBRESOURCE_TTL frames loses its ImFont and hitches when the
    // script needs it again. Detaching lets the TTL apply once more.
    if(it->isResourceValid() &&
        (++it->unusedFrames <= SUBRESOURCE_TTL || isAttached(it->resource))) {
      if(it->unusedFrames == 1)
        it->resource->update(this, it->data);
      if(it->unusedFrames > SUBRESOURCE_TTL)
        it->unusedFrames = SUBRESOURCE_TTL + 1; // hold below overflow
      ++it;
    }
    else {
      it->data.uninstall(this);
      it = m_subresources.erase(it);
    }
  }
}

ImTextureData *Context::createTexture()
{
  auto tex {new ImTextureData};
  m_imgui->UserTextures.push_back(tex);
  return tex;
}

void Context::cleanupTextures()
{
  for(int i {}; i < m_imgui->UserTextures.Size; ++i) {
    ImTextureData *tex {m_imgui->UserTextures[i]};
    if(tex->Status != ImTextureStatus_WantUpdates)
      tex->Updates.resize(0);
    if(tex->Status == ImTextureStatus_Destroyed) {
      IM_ASSERT(!tex->Pixels);
      delete tex;
      m_imgui->UserTextures.erase(m_imgui->UserTextures.begin() + i);
      m_imgui->PlatformIO.Textures.find_erase(tex);
      --i;
    }
  }
}

ImGuiViewport *Context::viewportUnder(const ImVec2 nativePos) const
{
  // Which window is under a point is a round trip to the window server on
  // macOS: about 0.1 ms of every frame of every context, and over 2 ms when
  // the server is busy. A viewport can only be under a point inside its own
  // window, so the question is asked only when one of them could be.
  bool candidate {false};
  // 0 is REAPER's main window
  for(int i {1}; i < m_imgui->Viewports.Size && !candidate; ++i) {
    const ImGuiViewport *viewport {m_imgui->Viewports[i]};
    candidate = viewport->PlatformHandle && Platform::windowMayContainPoint(
      static_cast<HWND>(viewport->PlatformHandle), nativePos);
  }
  if(!candidate)
    return nullptr;

  HWND target {Platform::windowFromPoint(nativePos)};
#ifdef __APPLE__
  target = GetParent(target);
#endif
  if(!target)
    return nullptr;

  ImGuiViewport *viewport {ImGui::FindViewportByPlatformHandle(target)};
  if(viewport && ImGui::GetMainViewport() != viewport)
    return viewport;

  return nullptr;
}

ImGuiViewport *Context::focusedViewport() const
{
  const ImGuiPlatformIO &pio {m_imgui->PlatformIO};
  for(int i {1}; i < pio.Viewports.Size; ++i) { // skip the main viewport
    ImGuiViewport *viewport {pio.Viewports[i]};
    Viewport *instance {static_cast<Viewport *>(viewport->PlatformUserData)};

    if(instance && instance->hasFocus())
      return viewport;
  }

  return nullptr;
}

void Context::updateFocus()
{
  // Injected input keeps the focus it gave while the person works elsewhere.
  if(m_testInput.owns())
    return;

  // Don't clear focus before any windows have been opened
  // so that the first window can have it
  // (only required when polling updateFocus every frame, eg. on Linux)
  bool hasHiddenWindows {false};
#ifdef FOCUS_POLLING
  for(ImGuiWindow *window : m_imgui->Windows) {
    if(window->Active && window->Hidden) {
      hasHiddenWindows = true;
      break;
    }
  }
#endif

  if(!hasHiddenWindows && !focusedViewport())
    clearFocus();
}

void Context::clearFocus()
{
  TempCurrent cur {this};

  if(ImGui::GetTopMostPopupModal())
    ImGui::ClearActiveID(); // don't close the current modal
  else
    ImGui::FocusWindow(nullptr); // also calls ClearActiveID

  // let UpdateViewportsNewFrame detect when the same viewport regains focus
  m_imgui->PlatformLastFocusedViewportId = ImGui::GetMainViewport()->ID;

  // ClearInputMouse resets MousePos to -FLT_MAX
  // Restoring it to gain focus on first click on Linux
  const ImVec2 mousePos {m_imgui->IO.MousePos};
  m_imgui->IO.ClearInputKeys();
  m_imgui->IO.ClearInputMouse();
  m_imgui->IO.MousePos = mousePos;
#ifdef __APPLE__
  m_stateFlags &= ~(RCE_Armed | RCE_Active);
  m_eventMouse.reset();
#endif

  HWND capture {Platform::getCapture()};
  if(capture && Window::contextFromHwnd(capture) == this) {
    Window *window
      {reinterpret_cast<Window *>(GetWindowLongPtr(capture, GWLP_USERDATA))};
    window->releaseMouse();
  }
}

void Context::enableViewports(const bool enable)
{
  const ImGuiPlatformIO &pio {m_imgui->PlatformIO};
  for(int i {1}; i < pio.Viewports.Size; ++i) { // skip the main viewport
    ImGuiViewport *viewport {pio.Viewports[i]};
    Viewport *instance {static_cast<Viewport *>(viewport->PlatformUserData)};
    EnableWindow(instance->nativeHandle(), enable);
  }
}

void Context::invalidateViewportsPos()
{
  const ImGuiPlatformIO &pio {m_imgui->PlatformIO};
  for(int i {}; i < pio.Viewports.Size; ++i)
    pio.Viewports[i]->PlatformRequestMove = true;
}

ImGuiViewport *Context::viewportAt(const ImVec2 position) const
{
  // The topmost of this context's own windows at an ImGui position, by the
  // order ImGui last focused them; REAPER's main window (0) is never one.
  const ImGuiPlatformIO &pio {m_imgui->PlatformIO};
  ImGuiViewportP *found {};
  for(int i {1}; i < pio.Viewports.Size; ++i) {
    auto *viewport {static_cast<ImGuiViewportP *>(pio.Viewports[i])};
    if(viewport->Flags & ImGuiViewportFlags_IsMinimized ||
        !viewport->GetMainRect().Contains(position))
      continue;
    if(!found || viewport->LastFocusedStampCount > found->LastFocusedStampCount)
      found = viewport;
  }
  return found;
}

void Context::testMove(const ImVec2 position)
{
  const ImGuiViewport *viewport {viewportAt(position)};
  m_testInput.move(m_imgui.get(), viewport ? viewport->ID : 0, position,
    testInputClock());
}

void Context::testButton(const int button, const bool down)
{
  m_testInput.button(m_imgui.get(), button, down, testInputClock());
}

void Context::testWheel(const float horizontal, const float vertical)
{
  m_testInput.wheel(m_imgui.get(), horizontal, vertical, testInputClock());
}

void Context::testKey(const ImGuiKey key, const bool down)
{
  m_testInput.key(m_imgui.get(), key, down, testInputClock());
}

void Context::testText(const char *utf8)
{
  m_testInput.text(m_imgui.get(), utf8, testInputClock());
}

void Context::testFocus(const char *window)
{
  // Focus inside ImGui only: keys arrive through TestInject, so the person's
  // focused application keeps the system keyboard. Applied when the next
  // frame begins, where FocusWindow belongs.
  m_testInput.hold(m_imgui.get(), testInputClock());
  m_testFocus = window ? window : "";
  m_testFocusPending = true;
}

void Context::testHold()
{
  m_testInput.hold(m_imgui.get(), testInputClock());
}

void Context::testRelease()
{
  if(!m_testInput.owns())
    return;
  m_testInput.release(m_imgui.get());
  m_testFocusPending = false;
  updateFocus(); // hand focus back to what the system says
}

void Context::applyTestFocus()
{
  if(!m_testFocusPending)
    return;
  m_testFocusPending = false;

  TestInput::focus(m_imgui.get(), m_testFocus.c_str());
}

bool Context::isAnyKeyDown() const
{
  for(const ImGuiKeyData &keyData : m_imgui->IO.KeysData) {
    if(keyData.Down)
      return true;
  }
  return false;
}

std::string Context::screensetKey() const
{
  return std::format("nvkgui:{:0{}X}", m_id, sizeof(m_id) * 2);
}

LRESULT Context::screensetProc(const int action, const char *id,
  void *user, void *param, const int paramSize)
{
  constexpr int SCREENSET_ACTION_GET_STATE_SIZE {0x102}; // v7.15+
  auto *self {static_cast<Context *>(user)};

  switch(action) {
  case SCREENSET_ACTION_LOAD_STATE:
    if(param) // null if save returned 0
      self->loadScreenset(static_cast<char *>(param), paramSize);
    return 0;
  case SCREENSET_ACTION_GET_STATE_SIZE:
    param = nullptr;
    [[fallthrough]];
  case SCREENSET_ACTION_SAVE_STATE:
    return self->saveScreenset(static_cast<char *>(param), paramSize);
  }

  return 0;
}

struct ScreensetHeader {
  uint32_t version, size;
};

void Context::loadScreenset(const char *buffer, unsigned long bufferSize)
{
  if(bufferSize < sizeof(ScreensetHeader))
    return;

  auto header {reinterpret_cast<const ScreensetHeader *>(buffer)};
  buffer += sizeof(*header), bufferSize -= sizeof(*header);

  if(Color::fromBigEndian(header->version) != 0)
    return;

  unsigned long dataSize {Color::fromBigEndian(header->size)};
  std::unique_ptr<char[]> data {new(std::nothrow) char[dataSize]};
  if(!data)
    return;

  if(Z_OK != uncompress(reinterpret_cast<unsigned char *>(data.get()), &dataSize,
      reinterpret_cast<const unsigned char *>(buffer), bufferSize))
    return;

  if(!dataSize || dataSize != Color::fromBigEndian(header->size))
    return;

  TempCurrent cur {this};
  ImGui::LoadIniSettingsFromMemory(data.get(), dataSize);
}

long Context::saveScreenset(char *buffer, unsigned long bufferSize)
{
  if(m_imgui->SettingsDirtyTimer > 0.0f) {
    TempCurrent cur {this};
    [[maybe_unused]] const char *data {ImGui::SaveIniSettingsToMemory()};
    assert(data == m_imgui->SettingsIniData.c_str());
  }

  const char *data {m_imgui->SettingsIniData.c_str()};
  const unsigned long dataSize {m_imgui->SettingsIniData.size() + 0ul};

  if(!buffer) // SCREENSET_ACTION_GET_STATE_SIZE
    return compressBound(dataSize);

  if(bufferSize < sizeof(ScreensetHeader))
    return 0;

  new(buffer) ScreensetHeader
    {Color::toBigEndian(0), Color::toBigEndian(dataSize)};
  buffer += sizeof(ScreensetHeader), bufferSize -= sizeof(ScreensetHeader);

  if(Z_OK != compress(reinterpret_cast<unsigned char *>(buffer), &bufferSize,
      reinterpret_cast<const unsigned char *>(data), dataSize))
    return 0;

  return sizeof(ScreensetHeader) + bufferSize;
}
