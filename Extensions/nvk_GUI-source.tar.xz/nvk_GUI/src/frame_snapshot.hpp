/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef REAIMGUI_FRAME_SNAPSHOT_HPP
#define REAIMGUI_FRAME_SNAPSHOT_HPP

#include <vector>

struct ImDrawData;

// An exact copy of what a window's frame draws: its position, size and scale,
// and every draw list's vertices, indices and commands (clip rectangles and
// texture references included). Two frames with equal snapshots render the
// same pixels, so a renderer whose window keeps showing its last frame can
// skip presenting the second one.
class FrameSnapshot {
public:
  // False when the frame cannot be compared: a texture still has updates to
  // upload (or is being destroyed), or a draw callback runs arbitrary code.
  bool capture(const ImDrawData *);
  // Compare in place without copying a second frame.
  bool matches(const ImDrawData *) const;
  void clear() { m_bytes.clear(); }
  bool empty() const { return m_bytes.empty(); }

  bool operator==(const FrameSnapshot &other) const { return m_bytes == other.m_bytes; }
  void swap(FrameSnapshot &other) { m_bytes.swap(other.m_bytes); }

private:
  std::vector<unsigned char> m_bytes;
};

#endif
