/* ReaImGui: ReaScript binding for Dear ImGui
 * Copyright (C) 2021-2025  Christian Fillion
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "font.hpp"

#include "context.hpp"
#include "error.hpp"
#include "font_registry.hpp"

#include <imgui/imgui_internal.h>
#include <imgui/misc/freetype/imgui_freetype.h>

#include <map>
#include <mutex>
#include <string>
#include <utility>

static void lookupFallbackFont(ImFontAtlas *atlas, ImFont *inst, const ImWchar c)
{
  // imgui caches the result per baked font (per size per ctx)
  auto font {static_cast<Font *>(inst->Sources.front()->UserData)};
  if(SysFont *sysfont {dynamic_cast<SysFont *>(font)})
    sysfont->addFallback(atlas, inst, c);
}

const ImFontLoader *Font::loader()
{
  static auto loader {*ImGuiFreeType::GetFontLoader()};
  loader.FontAddFallbackSrc = &lookupFallbackFont;
  return &loader;
}

Font::Font()
  : m_size {}
{
}

Font::Font(const char *file, const unsigned int index, const int flags)
  : m_src {file, index, flags}, m_size {}
{
}

Font::Font(std::vector<unsigned char> &&data, const unsigned int index, const int flags)
  : m_src {std::move(data), index, flags}, m_size {}
{
}

ImFont *Font::instance(Context *ctx)
{
  return ctx->touch<ImFont>(this);
}

static void uninstall(Context *ctx, ImFont *font)
{
  ctx->IO().Fonts->RemoveFont(font);
}

static void uninstallShared(Context *, ImFont *font)
{
  FontRegistry::release(font);
}

SubresourceData Font::install(Context *ctx)
{
  if(ctx->usesSharedAtlas()) {
    if(ImFont *inst {FontRegistry::acquire(this)})
      return {inst, &uninstallShared};
  }
  else if(ImFont *inst {m_src.install(ctx->IO().Fonts, this)}) {
    // don't set ImFontConfig::SizePixels to use EM square sizing
    inst->LegacySize = m_size;
    return {inst, &uninstall};
  }

  // imgui doesn't report what went wrong
  throw reascript_error {"the font could not be loaded"};
}

SysFont::SysFont(const char *family, const int flags)
  : Font {}, m_family {family}, m_styles {flags}
{
  initPlatform();

  // Resolving a family through the platform font matcher is expensive (about
  // 7 ms on macOS, where CoreText reopens the font file to read its
  // descriptors) and every context constructs a sans-serif SysFont, so the
  // successful answers are kept for the process. Failures are not cached:
  // a family installed later in the session still resolves on the next call.
  using Key = std::pair<std::string, int>;
  static std::map<Key, FontSource> g_resolved;
  static std::mutex g_mutex;

  Key key {m_family, m_styles};
  {
    std::lock_guard<std::mutex> lock {g_mutex};
    if(const auto it {g_resolved.find(key)}; it != g_resolved.end()) {
      m_src = it->second;
      return;
    }
  }

  auto src {resolve()};
  if(!src)
    throw reascript_error {"cannot find a matching system font"};

  m_src = std::move(*src);
  std::lock_guard<std::mutex> lock {g_mutex};
  g_resolved.emplace(std::move(key), m_src);
}

SysFont::SysFont(FontSource &&src, const int style)
  : Font {}, m_family {SANS_SERIF}, m_styles {style}
{
  initPlatform();
  m_src = std::move(src);
}

void SysFont::addFallback(ImFontAtlas *atlas, ImFont *inst, unsigned int codepoint)
{
  // ImGui always requests a tab from ImFontAtlasBuildSetupFontBakedBlanks which
  // often isn't present causing an unnecessary second lookup every time.
  if(codepoint == '\t')
    return;

  installMissingFallbacks(atlas, inst);

  // ImGui caches missing glyphs per baked size so, if none of the already added
  // font sources contains the requested codepoint, it will query again over and
  // over for every new size. Furthermore the resolver may return a font lacking
  // the requested codepoint. We must not wastefully retry regardless of result.
  if(m_resolved.contains(codepoint))
    return;
  else
    m_resolved.insert(codepoint);

  const auto src {resolve(codepoint)};
  if(src && *src != m_src) {
    m_fallbacks.push_back(*src);
    src->install(atlas, this, inst);
  }
}

bool SysFont::installMissingFallbacks(ImFontAtlas *atlas, ImFont *parent)
{
  bool installed {};
  for(size_t i {parent->Sources.Size - 1u}; i < m_fallbacks.size(); ++i)
    installed |= !!m_fallbacks[i].install(atlas, this, parent);
  return installed;
}

ImFont *FontSource::install(ImFontAtlas *atlas, Font *parent, ImFont *inst) const
{
  ImFontConfig cfg;
  // light hinting solves uneven glyph height on macOS
  cfg.FontLoaderFlags |= ImGuiFreeTypeLoaderFlags_LightHinting |
                         ImGuiFreeTypeLoaderFlags_LoadColor;
  if(m_styles & ReaImGuiFontFlags_Bold)
    cfg.FontLoaderFlags |= ImGuiFreeTypeLoaderFlags_Bold;
  if(m_styles & ReaImGuiFontFlags_Italic)
    cfg.FontLoaderFlags |= ImGuiFreeTypeLoaderFlags_Oblique;
  cfg.FontNo = m_index;
  cfg.UserData = parent;
  cfg.MergeTarget = inst;

  if(const std::string *path {std::get_if<std::string>(&m_data)})
    return atlas->AddFontFromFileTTF(path->c_str(), 0.f, &cfg);
  else {
    cfg.FontDataOwnedByAtlas = false;
    auto &data {std::get<std::vector<unsigned char>>(m_data)};
    auto bytes {const_cast<unsigned char *>(data.data())};
    return atlas->AddFontFromMemoryTTF(bytes, data.size(), 0.f, &cfg);
  }
}

bool FontSource::operator==(const FontSource &o) const
{
  return m_data == o.m_data && m_index == o.m_index && m_styles == o.m_styles;
}
