/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef REAIMGUI_DISPLAY_CLOCK_HPP
#define REAIMGUI_DISPLAY_CLOCK_HPP

// Ticks in step with the display so windows holding live native regions can
// be repainted between script frames (Context::replay). It runs only while
// some context asks for it and stops itself shortly after none does.
//
// macOS (a display link), Windows (DXGI's vblank wait) and Linux (a main-loop
// timer at the primary monitor's rate).
namespace DisplayClock {
  void request(); // a context has live regions: keep ticking for a while
  void teardown();
}

#endif
