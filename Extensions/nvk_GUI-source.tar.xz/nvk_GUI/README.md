# nvk_GUI: a ReaImGui fork for nvk scripts

A renamed fork of [ReaImGui](https://codeberg.org/cfillion/reaimgui) that
**coexists** with the stock extension: it registers its API as
`NvkGui_*`, ships as `reaper_nvkgui`, installs its Lua wrapper as
`Scripts/nvk/API/nvkgui.lua` (a development build) or
`Scripts/nvk-ReaScripts/Extensions/nvkgui.lua` (the nvk_API ReaPack package),
and keeps all of its on-disk and registered
state (ini files, screensets, action IDs, prefs page, ObjC classes) under
its own names. Stock ReaImGui keeps serving third-party scripts; our
scripts depend on this fork. Requires REAPER 7.28+.

This component is developed in the NVK Audio monorepo. Build and verify it with
`python3 tools/check.py gui` from the checkout root; that command does not deploy.
The historical standalone repositories are preserved separately.

The vendored Dear ImGui source is based on `v1.93.0-docking`
(`4e02e84cbb85d48881388e7090c2dfa1708c02a1`). ReaImGui's upstream baseline
remains `b3466c103d9ccd64b1192a2615f2188d1e739ab8` from
<https://codeberg.org/cfillion/reaimgui>. See [the upgrade notes](docs/IMGUI_UPGRADE.md)
for retained patches, compatibility decisions, and verification.

The fork is distributed inside the nvk_API ReaPack package. Publication and
installation follow the root monorepo workflow.

Licensed under the LGPL v3 or later, like upstream (see COPYING.LESSER).

## macOS developer input testing

Targeted automated mouse clicks are opt-in. With REAPER closed, set the following
in its resource-directory `REAPER.ini`, inside the existing `[nvkgui]` section:

```ini
[nvkgui]
dev_automation_input=1
```

Restart REAPER after changing it. Only the value `1` enables event-position input;
an absent key or any other value leaves the original system-cursor input path in
place. This hidden setting is local to that installation, is never enabled or
written by the extension, and is not part of script defaults or the preferences UI.
Remove the key or set it to `0` with REAPER closed to disable it.

When enabled, button events supply their own position until ImGui processes the
gesture. Physical cursor movement immediately resumes normal polling. The flag
does not enable automated dragging or scrolling, and does not affect stock ReaImGui.
`tests/event_mouse_test.cpp` covers both modes, including normal clicks, movement
during a drag, release cancellation, focus reset, and the default-off path.

## Scripted test input

`TestInject` (Lua `ImGui.TestInject`, guarded with `rawget(ImGui, 'TestInject')`) lets
a script queue synthetic mouse, wheel, key and text input for its own context, in
ImGui coordinates, without the system mouse or keyboard; it needs no setting. While
injection owns a context the real cursor is not polled and real input in it is
ignored until the sequence goes idle and the person clicks, types, scrolls or points
at it again, or the script sends `release`. `src/test_input.hpp` describes the rules
and `tests/test_input_test.cpp` covers them. SHARED's `DevInput` wraps it for nvk
scripts.

## Build from source

On macOS this is normally built for you: nvk_API's `./build.sh` runs the Meson
steps below with `-Dresource_path` pointed at the REAPER install, after
building nvk_API itself. The rest of this section is for building the extension
on its own.

### Prerequisites

Software requirements:

- [Meson](https://mesonbuild.com/) (1.1 or newer)
- C++20 compiler* (C++17 is supported for Linux and macOS builds)
- PHP (optional, for preprocessing of gfx2imgui.lua)

(* The C++ compiler must be ABI-compatible with MSVC on Windows)

Library requirements:

By default these will be picked up from the system or downloaded if missing.

- [Boost](https://www.boost.org/) (1.81 or newer)
- [fmt](https://fmt.dev/) (only if C++20 is not available)
- [FreeType](https://www.freetype.org/)
- [GoogleTest](https://github.com/google/googletest)
- [libjpeg-turbo](https://www.libjpeg-turbo.org/)
- [libpng](http://www.libpng.org/pub/png/libpng.html)
- [md4c](https://github.com/mity/md4c)
- [zlib](https://www.zlib.net/)

Additional system dependencies on Linux:

- [Fontconfig](https://www.fontconfig.org)
- [GDK3](https://developer.gnome.org/gdk3/stable/) (3.22 or newer)
- [libepoxy](https://github.com/anholt/libepoxy)

### Compile and install

In the nvk_API checkout the sources are already there; make sure this fork's own
submodules are:

    $ git submodule update --init --recursive

On a machine that has no nvk_API checkout, clone it with its submodules (never
as a second copy beside that one):

    $ git clone --recursive --shallow-submodules https://github.com/nickvonkaenel/nvk_GUI.git

Build nvk_GUI using Meson:

    $ meson setup build
    $ cd build
    $ ninja

To change the installation directory to a portable install:

    $ meson configure -Dresource_path=~/path/to/your/portable/install/

Downgrade to C++17 if compiling on macOS with Xcode older than 14:

    $ meson configure -Dcpp_std=c++17

Run the test suite using:

    $ meson test

Install nvk_GUI into your REAPER resource path using:

    $ meson install --tags runtime

### Cross-compilation

#### Linux

QEMU is used to run compiled binaries for binding generation and tests.

    meson setup build/i686    --cross-file cross/i686-linux-gnu.ini
    meson setup build/armv7l  --cross-file cross/arm-linux-gnueabihf.ini
    meson setup build/aarch64 --cross-file cross/aarch64-linux-gnu.ini

#### macOS

macOS 10.14 (or older) and Xcode 9 are required for producing 32-bit builds.
Xcode 12 is required to compile for ARM64.

    export MACOSX_DEPLOYMENT_TARGET=10.9
    meson setup build/i386 --cross-file cross/i386-darwin.ini

    export MACOSX_DEPLOYMENT_TARGET=11.0
    meson setup build/arm64 --cross-file cross/arm64-darwin.ini
