/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "helper.hpp"

API_SECTION("Error Recovery",
R"(Keep a context alive through ImGui's recoverable errors, such as a missing
End or a cursor moved past a child's boundary. ImGui unwinds its stacks at the
end of the frame and the script can tell its user what happened.
nvk_GUI only.)");

API_FUNC(0_10, void, SetErrorRecovery, (Context*,ctx)
(bool,enable),
R"(When enabled, recoverable errors no longer end the context: they are kept
for TakeRecoveredError and ImGui recovers its state. Errors ImGui cannot
recover from still end the context. Off by default.)")
{
  assertValid(ctx);
  ctx->setErrorRecovery(enable);
}

API_FUNC(0_10, const char*, TakeRecoveredError, (Context*,ctx),
R"(The first recoverable error since the last call, with how many followed it,
or an empty string. Taking it clears it.)")
{
  assertValid(ctx);
  return ctx->takeRecoveredError();
}
