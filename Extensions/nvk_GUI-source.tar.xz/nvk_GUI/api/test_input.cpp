/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "helper.hpp"

#include <string_view>

API_SECTION("Test Input",
R"(Synthetic mouse and keyboard input a script queues for its own context, so a
test harness can hover, click, drag, scroll and type without the system mouse
or keyboard. nvk_GUI only.)");

API_FUNC(0_10, void, TestInject, (Context*,ctx)
(const char*,kind) (RO<double*>,x,0.0) (RO<double*>,y,0.0)
(RO<const char*>,text,""),
R"(Queue one synthetic input event for the context. Events reach ImGui in call
order when the next frame begins, spread over frames the way real input is.
Queue a move a frame or two before a button so hover lands first.

Kinds:
- "mouse_move": x, y in ImGui coordinates (the space of GetWindowPos and
  GetMousePos: points on macOS).
- "mouse_down", "mouse_up": x is the button (MouseButton_Left, _Right, _Middle).
- "mouse_wheel": x horizontal, y vertical, in wheel notches (y > 0 scrolls up).
- "key_down", "key_up": x is a Key_* or Mod_* value, for a physical key: on
  macOS with ConfigVar_MacOSXBehaviors, Mod_Super is Command and reaches the
  script as Mod_Ctrl, as real input does.
- "text": text is UTF-8 characters to type.
- "focus": focus the window named by text, inside ImGui only (the system
  keyboard focus is not changed). Focus already in that window, one of its
  popups or one of its child windows stays where it is, so an open popup is
  not closed, and a window below an open modal is not focused. With empty
  text, the frontmost window is focused only when none of the context's
  windows has focus.
- "hold": keep a waiting sequence busy without an event.
- "release": give the context back to real input, lifting any injected button
  or key still held.

The first injection takes the context's input: the system cursor is no longer
read, so an injected hover stays while the person uses the computer, and real
clicks, keys and scrolling in the context are ignored while a sequence is busy
(an injection within the last half second). Once it is idle, pressing a button
or key in one of the context's windows, scrolling one, or moving the pointer
over one gives the context back, as does "release".)")
{
  assertValid(ctx);
  const std::string_view what {kind};
  const double first {API_GET(x)}, second {API_GET(y)};

  if(what == "mouse_move")
    ctx->testMove(ImVec2(first, second));
  else if(what == "mouse_down" || what == "mouse_up") {
    const int button {static_cast<int>(first)};
    if(button < 0 || button >= ImGuiMouseButton_COUNT || button != first)
      throw reascript_error {"invalid mouse button"};
    ctx->testButton(button, what == "mouse_down");
  }
  else if(what == "mouse_wheel")
    ctx->testWheel(first, second);
  else if(what == "key_down" || what == "key_up") {
    const ImGuiKey key {static_cast<ImGuiKey>(first)};
    if(static_cast<double>(key) != first || !TestInput::validKey(key))
      throw reascript_error {"invalid key"};
    ctx->testKey(key, what == "key_down");
  }
  else if(what == "text")
    ctx->testText(API_GET(text));
  else if(what == "focus")
    ctx->testFocus(API_GET(text));
  else if(what == "hold")
    ctx->testHold();
  else if(what == "release")
    ctx->testRelease();
  else
    throw reascript_error {"unknown test input kind"};
}
