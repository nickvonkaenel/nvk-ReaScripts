/* nvk_GUI (ReaImGui fork)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "helper.hpp"

#include "drawlist.hpp"

#include "../src/native_region.hpp"

API_REGISTER_TYPE(NvkGui_RegionDrawer, "NvkGui_RegionDrawer");
API_REGISTER_TYPE(void*, "void*");

API_SECTION("Native Region",
R"(Rectangles of a draw list painted by a native extension rather than by the
script, so they can be repainted without waiting for the script's next frame.
nvk_GUI only.)");

API_FUNC(0_10, bool, DrawList_AddNativeRegion, (DrawListProxy*,draw_list)
(const char*,drawer) (double,key) (double,p_min_x) (double,p_min_y)
(double,p_max_x) (double,p_max_y),
R"(Lets the native drawer registered under this name paint the rectangle.
The key is passed to the drawer to tell regions apart, for example the data
source to show. Drawing order follows call order: draw what goes behind the
region before this call and what goes in front of it after. The region takes no
space and receives no input; pair it with InvisibleButton for interaction.
Text the drawer paints uses the font and size current at this call, as
DrawList_AddText would here, and only glyphs this frame has already drawn.

Returns false, drawing nothing, when no drawer is registered under this name.
Draw the content another way in that case.)")
{
  const int index {NativeRegion::findDrawer(drawer)};
  if(index < 0)
    return false;

  return NativeRegion::add(draw_list->get(), index, key,
    ImVec2(p_min_x, p_min_y), ImVec2(p_max_x, p_max_y));
}

API_FUNC_NATIVE(0_10, int, RegisterNativeRegionDrawer,
(const char*,name) (NvkGui_RegionDrawer,func) (void*,user),
R"(Registers the function painting the native regions scripts add under this
name with DrawList_AddNativeRegion. Registering the same name again replaces
the function; NULL disables it. See native_region_abi.h for the drawer and
painter interface. Returns the native region interface version.)")
{
  if(!name || !*name)
    throw reascript_error {"a drawer name is required"};

  NativeRegion::registerDrawer(name, func, user);
  return NVKGUI_NATIVE_REGION_ABI_VERSION;
}
